const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// const favItemSchema = new Schema({
//     id : {
//         type: String,
//         required: true
//     },
//     itemId : {
//         type: String,
//         required: true
//     },
//     isFavourite : {
//         type : Boolean,
//         required: true
//     }
// })

// const FavItem = mongoose.model("FavItems",favItemSchema);
// module.export = FavItem;
// models/FavItem.js

const favItemSchema = new mongoose.Schema({
  username: { type: String, required: true }, // Track by username instead of userId
  itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true }, // Keep itemId as ObjectId
}, { timestamps: true });

const FavItem = mongoose.model('FavItem', favItemSchema);
module.exports = FavItem;

