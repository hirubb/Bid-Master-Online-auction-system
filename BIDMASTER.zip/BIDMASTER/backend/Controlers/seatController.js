const { json } = require('express');
const Seat = require('../models/Seat'); // Import the Seat model
const nodemailer = require('nodemailer');

exports.submitForm = async(req,res) => {
    const { seatId, date, name, email, location } = req.body;

    if (!seatId || !date || !name || !email || !location) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        // Check if a seat with the same seatId exists in the same location
        const seatExists = await Seat.findOne({ seatId, location });
        if (seatExists) {
            return res.status(400).json({ error: `Seat ID ${seatId} is already assigned in ${location}` });
        }

        const newSeat = new Seat({ seatId, date, name, email, location });
        const savedSeat = await newSeat.save();
        sendSubmitConfirmMail(seatId, date,name,email,location)

        console.log(savedSeat)
        res.status(201).json({ message: 'Seat created successfully', seat: savedSeat });
    } catch (error) {
        console.error('Error creating seat:', error);
        res.status(500).json({ error: 'Server error' });
    }
}

exports.getSeat = async(req,res) => {
    try {
        const seats = await Seat.find();
        res.json(seats);
    } catch (error) {
        console.error('Error fetching seats:', error);
        res.status(500).json({ error: 'Server error' });
    }
}

exports.updateSeat = async(req,res) => {
    const { id } = req.params;
    const { seatId, date, name, email, location } = req.body;

    try {
        const updatedSeat = await Seat.findByIdAndUpdate(
            id,
            { seatId, date, name, email, location },
            { new: true, runValidators: true }
        );

        if (!updatedSeat) {
            return res.status(404).json({ error: 'Seat not found' });
        }
    
        sendSubmitConfirmMail(seatId, date, name, email, location);

        res.json({ message: 'Seat updated successfully', seat: updatedSeat });
    } catch (error) {
        console.error('Error updating seat:', error);
        res.status(500).json({ error: 'Server error' });
    }
}

exports.deleteSeat = async(req,res) => {
    const { id } = req.params;

    try {
        const deletedSeat = await Seat.findByIdAndDelete(id);

        if (!deletedSeat) {
            return res.status(404).json({ error: 'Seat not found' });
        }

        res.json({ message: 'Seat deleted successfully' });
    } catch (error) {
        console.error('Error deleting seat:', error);
        res.status(500).json({ error: 'Server error' });
    }
}

const sendSubmitConfirmMail = async(seatId, date,bidderName,bidderEmail,location) => {
    

    // Create a transporter using SMTP
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // Use TLS
      auth: {
        user: "anu.induwari2002@gmail.com", //Gmail address
        pass: "swoh drwk qyvg zjyr" // Gmail app password
      },
    });

    try {
      // Send email
      await transporter.sendMail({
        from: '"BidMaster"',
        to: bidderEmail,
        subject: "BIDMASTER - Your seat has been reserved",
        text: `
          Congratulation ${bidderName}! Your seat no ${seatId} is reserved on ${date} at ${location}
        `,
        html: `
          <h1>Your seat has been reserved</h1>
          <p>Congratulation ${bidderName}! Your seat no ${seatId} is reserved on ${date} at ${location}</p>
        `,
      });

      
    } catch (error) {
      console.error(error);
     
    }
}

