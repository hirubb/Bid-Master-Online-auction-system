const express = require('express');
const FavItem = require('../models/FavItem');
const  authMiddleware  = require('../routes/authMiddleware');
const router = express.Router();

// Add or remove favorite item
router.post('/',authMiddleware, async (req, res) => {
  const { itemId } = req.body;
  const username = req.body.username; // Get user ID from verified token

  try {
    // Check if the item is already favorited
    const existingFav = await FavItem.findOne({ username, itemId });

    if (existingFav) {
      // Item already in favorites, remove it
      await FavItem.deleteOne({ _id: existingFav._id });
      return res.status(200).json({ success: true, message: 'Item removed from favorites' });
    } else {
      // Item not in favorites, add it
      const favItem = new FavItem({ username, itemId });
      await favItem.save();
      return res.status(200).json({ success: true, message: 'Item added to favorites' });
    }
  } catch (error) {
    console.error("Error updating favorites:", error);
    return res.status(500).json({ message: 'Server error' });
  }
});

// Get favorite items for a user
router.get('/', async (req, res) => {
  const userId = req.user._id;

  try {
    const favorites = await FavItem.find({ userId }).populate('itemId');
    res.status(200).json(favorites);
  } catch (error) {
    console.error("Error fetching favorite items:", error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
