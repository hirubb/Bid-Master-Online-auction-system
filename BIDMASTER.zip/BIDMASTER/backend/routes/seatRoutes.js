const express = require('express');
const router = express.Router();
const {submitForm, getSeat, updateSeat, deleteSeat} = require('../Controlers/seatController')


// Create a new seat (POST)
router.post('/seats', async (req, res) => {
    await submitForm(req,res);
});


// Get all seats (GET)
router.get('/seats', async (req, res) => {
    await getSeat(req,res);
});

// Update a seat (PUT)
router.put('/update/:id', async (req, res) => {
    await updateSeat(req,res);
});

// Delete a seat (DELETE)
router.delete('/delete/:id', async (req, res) => {
    await deleteSeat(req,res);
});

module.exports = router;
