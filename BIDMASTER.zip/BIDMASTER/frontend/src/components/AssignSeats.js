import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation as useRouterLocation } from 'react-router-dom';
import axios from 'axios';

export default function AssignSeats() {
  const navigate = useNavigate();
  const location = useRouterLocation(); // Access location to get passed seat data

  const [formData, setFormData] = useState({
    seatId: '',
    date: '', 
    name: '',
    email: '',
    location: ''
  });

  const [formErrors, setFormErrors] = useState({
    date: '',
    name: '',
    email: ''
  });

  const [isEditMode, setIsEditMode] = useState(false);
  const [seatId, setSeatId] = useState(null);
  const [seats, setSeats] = useState([]);
  const [existingSeats, setExistingSeats] = useState([]); // Store existing seats

  const [locationsArray] = useState([
    "BMICH",
    "Negombo Regal",
    "Joash Place Maharagama"
  ]);

  useEffect(() => {
    const generateSeatIds = () => {
      const seatIds = [];
      for (let letter = 'A'.charCodeAt(0); letter <= 'H'.charCodeAt(0); letter++) {
        for (let number = 1; number <= 15; number++) {
          seatIds.push(String.fromCharCode(letter) + number);
        }
      }
      return seatIds;
    };

    const fetchSeats = async () => {
      try {
        const response = await axios.get('http://localhost:8070/test1/seats');
        setExistingSeats(response.data);
        setSeats(generateSeatIds()); // Generate seat IDs for the dropdown
      } catch (error) {
        console.error('Error fetching seats:', error);
      }
    };

    fetchSeats();

    if (location.state && location.state.seat) {
      const seat = location.state.seat;
      setFormData({
        seatId: seat.seatId,
        date: seat.date || '',
        name: seat.name || '',
        email: seat.email || '',
        location: seat.location || ''
      });
      setSeatId(seat._id);
      setIsEditMode(true);
    }
  }, [location.state]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'date') {
      setFormData({
        ...formData,
        [name]: value
      });
    }

    if (name === 'name') {
      const validValue = value.replace(/[^a-zA-Z\s]/g, ''); // Allow only letters and spaces
      setFormData({
        ...formData,
        [name]: validValue
      });
    }

    if (name === 'email') {
      setFormData({
        ...formData,
        [name]: value // Let the email field handle itself but type will still validate
      });
    }

    if (name === 'seatId' || name === 'location') {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    validateField(name, value);
  };

  const validateField = (name, value) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const nameRegex = /^[a-zA-Z\s]+$/;

    let error = '';

    if (name === 'date') {
      const selectedDate = new Date(value);
      const currentDate = new Date();
      if (isNaN(selectedDate.getTime()) || selectedDate < currentDate) {
        error = '';
      }
    }

    if (name === 'name' && !nameRegex.test(value)) {
      error = '';
    }

    if (name === 'email' && !emailRegex.test(value)) {
      error = '';
    }

    setFormErrors(prevErrors => ({
      ...prevErrors,
      [name]: error
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formErrors.date || formErrors.name || formErrors.email) {
      alert('Please fix the errors before submitting.');
      return;
    }

    if (!formData.seatId || !formData.location) {
      alert('Please select a seat and location');
      return;
    }

    if (!isSeatUnique()) {
      alert(`Seat ID ${formData.seatId} is already assigned in ${formData.location}.`);
      return;
    }

    try {
      const url = isEditMode
        ? `http://localhost:8070/test1/update/${seatId}`
        : 'http://localhost:8070/test1/seats';
      const method = isEditMode ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert(`Seat ${isEditMode ? 'updated' : 'assigned'} successfully`);
        navigate('/Table');
      } else {
        const responseData = await response.json();
        alert(`Failed to ${isEditMode ? 'update' : 'assign'} seat: ${responseData.error}`);
      }
    } catch (error) {
      console.error('Error:', error);
      alert(`An error occurred while ${isEditMode ? 'updating' : 'assigning'} the seat.`);
    }
  };

  const handleViewTable = () => {
    navigate('/Table'); // Navigate to the table view
  };

  const isSeatUnique = () => {
    return !existingSeats.some(seat => seat.seatId === formData.seatId && seat.location === formData.location);
  };

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      backgroundColor: '#f0f0f5',
      padding: '20px'
    }}>
      <div style={{
        display: 'flex',
        backgroundColor: '#fff',
        padding: '30px',
        borderRadius: '12px',
        boxShadow: '0 0 15px rgba(0, 0, 0, 0.1)',
        maxWidth: '900px',
        width: '100%',
        border: '1px solid #ddd',
      }}>
        <div style={{ marginRight: '20px' }}>
          <img src="Assests/auctionimg.jpg" alt="" style={{ width: '400px', height: '550px', borderRadius: '8px', objectFit: 'cover' }} />
        </div>

        <div style={{ width: '100%' }}>
          <h2 style={{ textAlign: 'center', marginBottom: '20px', color: '#333', fontSize: '28px' }}>Assign Seat Form</h2>
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '15px' }}>
              <label htmlFor="seatId" style={{ display: 'block', marginBottom: '5px', textAlign: 'left', fontWeight: 'bold', color: '#333' }}>Seat ID:</label>
              <select
                id="seatId"
                name="seatId"
                value={formData.seatId}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  boxSizing: 'border-box',
                  fontSize: '16px',
                  color: '#555'
                }}
              >
                <option value="">Select Seat</option>
                {seats.map(seat => (
                  <option key={seat} value={seat}>{seat}</option>
                ))}
              </select>
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label htmlFor="date" style={{ display: 'block', marginBottom: '5px', textAlign: 'left', fontWeight: 'bold', color: '#333' }}>Date:</label>
              <input
                type="date"
                id="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                onBlur={handleBlur}
                required
                min={new Date().toISOString().split('T')[0]} // Setting the minimum date to today's date
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  boxSizing: 'border-box',
                  fontSize: '16px',
                  color: '#555'
                }}
              />
              {formErrors.date && <p style={{ color: 'red', marginTop: '5px' }}>{formErrors.date}</p>}
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label htmlFor="name" style={{ display: 'block', marginBottom: '5px', textAlign: 'left', fontWeight: 'bold', color: '#333' }}>Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                onBlur={handleBlur}
                required
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  boxSizing: 'border-box',
                  fontSize: '16px',
                  color: '#555'
                }}
              />
              {formErrors.name && <p style={{ color: 'red', marginTop: '5px' }}>{formErrors.name}</p>}
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label htmlFor="email" style={{ display: 'block', marginBottom: '5px', textAlign: 'left', fontWeight: 'bold', color: '#333' }}>Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                onBlur={handleBlur}
                required
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  boxSizing: 'border-box',
                  fontSize: '16px',
                  color: '#555'
                }}
              />
              {formErrors.email && <p style={{ color: 'red', marginTop: '5px' }}>{formErrors.email}</p>}
            </div>

            <div style={{ marginBottom: '15px' }}>
              <label htmlFor="location" style={{ display: 'block', marginBottom: '5px', textAlign: 'left', fontWeight: 'bold', color: '#333' }}>Location:</label>
              <select
                id="location"
                name="location"
                value={formData.location}
                onChange={handleChange}
                required
                style={{
                  width: '100%',
                  padding: '12px',
                  border: '1px solid #ccc',
                  borderRadius: '8px',
                  boxSizing: 'border-box',
                  fontSize: '16px',
                  color: '#555'
                }}
              >
                <option value="">Select Location</option>
                {locationsArray.map(loc => (
                  <option key={loc} value={loc}>{loc}</option>
                ))}
              </select>
            </div>

            <div style={{ textAlign: 'center', marginTop: '20px' }}>
              <button
                type="submit"
                style={{
                  backgroundColor: '#4CAF50',
                  color: 'white',
                  padding: '12px 24px',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '16px',
                  cursor: 'pointer',
                  transition: 'background-color 0.3s ease',
                  marginRight: '10px'
                }}
                onMouseOver={(e) => e.target.style.backgroundColor = '#45a049'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#4CAF50'}
              >
                {isEditMode ? 'Update Seat' : 'Submit'}
              </button>
            
              <button
                type="button"
                onClick={handleViewTable}
                style={{
                  backgroundColor: '#007BFF',
                  color: 'white',
                  padding: '12px 24px',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '16px',
                  cursor: 'pointer',
                  transition: 'background-color 0.3s ease'
                }}
                onMouseOver={(e) => e.target.style.backgroundColor = '#0069d9'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#007BFF'}
              >
                View Table
              </button>
            </div>


          </form>
        </div>
      </div>
    </div>
  );
}
