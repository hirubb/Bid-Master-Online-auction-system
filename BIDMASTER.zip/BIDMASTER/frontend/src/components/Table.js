import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

export default function Table() {
  const [seats, setSeats] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState('');
  const [filteredSeats, setFilteredSeats] = useState([]);
  const navigate = useNavigate();

  // Fetch seats from the server
  const fetchSeats = async () => {
    try {
      const response = await fetch('http://localhost:8070/test1/seats');
      if (response.ok) {
        const data = await response.json();
        setSeats(data);
        setFilteredSeats(data);
      } else {
        console.error('Failed to fetch seats');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Fetch seats when the component mounts
  useEffect(() => {
    fetchSeats();
  }, []);

  // Handle searching seatId
  const handleSearch = (event) => {
    const query = event.target.value;
    setSearchQuery(query);
    const filtered = seats.filter(seat =>
      seat.seatId.toLowerCase().includes(query.toLowerCase()) &&
      (filterLocation === '' || seat.location === filterLocation)
    );
    setFilteredSeats(filtered);
  };

  // Handle filtering by location
  const handleFilterLocation = (event) => {
    const location = event.target.value;
    setFilterLocation(location);
    const filtered = seats.filter(seat =>
      seat.seatId.toLowerCase().includes(searchQuery.toLowerCase()) &&
      (location === '' || seat.location === location)
    );
    setFilteredSeats(filtered);
  };

  // Handle updating a seat
  const handleUpdate = (seat) => {
    navigate('/AssignSeats', { state: { seat } });
  };

  // Handle deleting a seat
  const handleDelete = async (id) => {
    const confirmed = window.confirm('Are you sure you want to delete this seat?');
    if (!confirmed) return;
    try {
      const response = await fetch(`http://localhost:8070/test1/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        await fetchSeats(); // Refresh the table after deletion
      } else {
        alert('Failed to delete seat');
      }
    } catch (error) {
      console.error('Error deleting seat:', error);
      alert('An error occurred while deleting the seat.');
    }
  };

  // Function to generate PDF report
  const generatePDF = () => {
    const doc = new jsPDF();
    
    const logo= "/Assests/bid-master-logo-zip-file/png/logo-color.png";
    doc.addImage(logo, 'PNG', 130, 0, 80, 80);

    // Company information at the top of the document
    
    doc.setFontSize(14);
    doc.text('Arcade Independence Square,', 14, 28); 
    doc.text('Colombo 07.', 14, 34); 
    doc.text('Sri Lanka.', 14, 40); 
    doc.text('Call us: +94 xxxxxxxx', 14, 48); 
    ///////
    
    doc.text('Mail us: ', 14, 58); // Email label

    // Set text color to black for the email address
    doc.setTextColor(0,0,255); // RGB for blue
    doc.text(' bidmaster@gmail.com', 13, 64); // Email address

    // Reset text color to black for subsequent text
    doc.setTextColor(0, 0, 0); // Reset to black
    ///////////

    // Add a horizontal line
    doc.setLineWidth(0.5);
    doc.line(14, 66, 200, 66);

    // Subtitle for the table
    doc.setFontSize(16);
    doc.text('Seats Assignment Report', 14, 76);

    // Table headers and rows
    const tableColumn = ["Seat ID", "Bidder ID", "Name", "Email", "Location"];
    const tableRows = [];

    filteredSeats.forEach(seat => {
      const seatData = [
        seat.seatId,
        seat.bidderId,
        seat.name,
        seat.email,
        seat.location
      ];
      tableRows.push(seatData);
    });

    // AutoTable for seating information
    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 90,
    });

    // Calculate Y position for the signature section after the table
    const finalY = doc.autoTable.previous.finalY + 20;

    
    doc.text('....................................', 14, finalY ); // Placeholder for signature
    doc.setFontSize(12);
    doc.text('Manager', 14, finalY + 6); // Placeholder for position

    // Date and signature line at the bottom
    doc.setFontSize(10);
    const currentDate = new Date().toLocaleDateString();
    doc.text(`Date: ${currentDate}`, 14, finalY + 14); // Display current date


    // Save the PDF
    doc.save('SeatsReport.pdf');
  };

  // Handle navigation
  const handleNavigate = (location) => {
    navigate(`/${location}`);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', position: 'relative' }}>
      <h1 style={{ marginBottom: '20px', color: '#000000', textAlign: 'center' }}>Seats List</h1>

      {/* Search and Filter Section */}
      <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center', gap: '20px', alignItems: 'center' }}>
        {/* Search Seat ID */}
        <input
          type="text"
          placeholder="Search by Seat ID"
          value={searchQuery}
          onChange={handleSearch}
          style={{
            padding: '8px',
            border: '1px solid #ccc',
            borderRadius: '5px',
            width: '200px',
            boxSizing: 'border-box'
          }}
        />

        {/* Filter by Location */}
        <select
          value={filterLocation}
          onChange={handleFilterLocation}
          style={{
            backgroundColor: '#007bff',
            color: '#fff',
            padding: '10px',
            border: '1px solid #ccc',
            borderRadius: '5px',
            width: '100px',
            boxSizing: 'border-box'
          }}
        >
          <option value="">Filter</option>
          <option value="BMICH">BMICH</option>
          <option value="Negombo Regal">Negombo Regal</option>
          <option value="Joash Place Maharagama">Joash Place Maharagama</option>
        </select>

        
        
      </div>

      {/* Table */}
      <div style={{ position: 'relative' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #000000' }}>
          <thead>
            <tr style={{ backgroundColor: '#f4f4f4', color: '#333' }}>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Seat ID</th>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Date</th>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Name</th>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Email</th>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Location</th>
              <th style={{ border: '1px solid #000000', padding: '12px', backgroundColor: '#C7C7C7' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredSeats.map((seat) => (
              <tr key={seat._id}>
                <td style={{ border: '1px solid #000000', padding: '12px' }}>{seat.seatId}</td>
                <td style={{ border: '1px solid #000000', padding: '12px' }}>{seat.date}</td>
                <td style={{ border: '1px solid #000000', padding: '12px' }}>{seat.name}</td>
                <td style={{ border: '1px solid #000000', padding: '12px' }}>{seat.email}</td>
                <td style={{ border: '1px solid #000000', padding: '12px' }}>{seat.location}</td>
                <td style={{ border: '1px solid #000000', padding: '12px', textAlign: 'center' }}>
                  <button
                    onClick={() => handleUpdate(seat)}
                    style={{
                      padding: '8px 12px',
                      backgroundColor: '#28a745',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '5px',
                      marginRight: '5px',
                    }}
                  >
                    Update
                  </button>
                  <button
                    onClick={() => handleDelete(seat._id)}
                    style={{
                      padding: '8px 12px',
                      backgroundColor: '#dc3545',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '5px',
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Navigation Buttons */}
        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <button onClick={() => handleNavigate('BMICH')} style={navButtonStyle}>Location: BMICH</button>
          <button onClick={() => handleNavigate('NegomboRegal')} style={navButtonStyle}>Location: Negombo Regal</button>
          <button onClick={() => handleNavigate('JoashPlaceMaharagama')} style={navButtonStyle}>Location: Joash Place Maharagama</button>
        </div>

          {/* PDF Generation Button */}
        <div style={{ marginTop: '20px', textAlign: 'Right', margin: '80px',  }}>
        <button
          onClick={generatePDF}
          style={{
            padding: '10px 20px',
            backgroundColor: '#28a745',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
          }}
        >
          Generate PDF
        </button>
        </div>
        
      </div>
    </div>
  );
}

const navButtonStyle = {
  margin: '10px', 
  padding: '10px 20px', 
  backgroundColor: '#007bff',
  color: '#fff',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};
