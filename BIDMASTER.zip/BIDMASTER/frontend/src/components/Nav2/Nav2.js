import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

function Nav() {
  const location = useLocation();
  const [clickedItem, setClickedItem] = useState(null);

  useEffect(() => {
    const path = location.pathname;
    if (path === "/mainDashboard") setClickedItem("dashboard");
    else if (path === "/AddAdvertisement") setClickedItem("addAdvertisement");
    else if (path === "/AdvertisementDetails")
      setClickedItem("advertisementDetails");
  }, [location]);

  const navStyle = {
    display: "flex", // Display flex to align items horizontally
    justifyContent: "center", // Center the navigation bar
    backgroundColor: "#333", // Background color of the nav
    padding: "10px 0", // Add padding for spacing
  };

  const ulStyle = {
    listStyleType: "none", // Remove bullet points
    margin: "0",
    padding: "0",
    display: "flex", // Make the list horizontal
    gap: "20px", // Space between each navigation link
  };

  const liStyle = {
    display: "inline-block", // Ensure links stay inline
  };

  const linkStyle = {
    fontSize: "18px",
    color: "white",
    textDecoration: "none",
    padding: "10px 20px", // Padding for clickable area
    transition: "color 0.3s ease",
    display: "inline-block",
  };

  const buttonContainerStyle = {
    border: "1px solid #444", // Border for buttons
    borderRadius: "5px", // Rounded corners
    transition: "background-color 0.3s ease",
    padding: "10px 20px",
  };

  const handleClick = (item) => {
    setClickedItem(item);
  };

  return (
    <nav style={navStyle}>
      <ul style={ulStyle}>
        <li style={liStyle}>
          <div
            style={{
              ...buttonContainerStyle,
              backgroundColor: clickedItem === "dashboard" ? "#444" : "#333",
            }}
            onClick={() => handleClick("dashboard")}
          >
            <Link
              to="/mainDashboard"
              style={{
                ...linkStyle,
                color: clickedItem === "dashboard" ? "grey" : "white",
              }}
            >
              Dashboard
            </Link>
          </div>
        </li>
        <li style={liStyle}>
          <div
            style={{
              ...buttonContainerStyle,
              backgroundColor:
                clickedItem === "addAdvertisement" ? "#444" : "#333",
            }}
            onClick={() => handleClick("addAdvertisement")}
          >
            <Link
              to="/AddAdvertisement"
              style={{
                ...linkStyle,
                color: clickedItem === "addAdvertisement" ? "grey" : "white",
              }}
            >
              Add Advertisement
            </Link>
          </div>
        </li>
        <li style={liStyle}>
          <div
            style={{
              ...buttonContainerStyle,
              backgroundColor:
                clickedItem === "advertisementDetails" ? "#444" : "#333",
            }}
            onClick={() => handleClick("advertisementDetails")}
          >
            <Link
              to="/AdvertisementDetails"
              style={{
                ...linkStyle,
                color:
                  clickedItem === "advertisementDetails" ? "grey" : "white",
              }}
            >
              Advertisement Details
            </Link>
          </div>
        </li>
      </ul>
    </nav>
  );
}

export default Nav;
