import React, { useState, useEffect } from "react";
import { useParams,Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const Item = () => {
    const { id } = useParams();
    const [itemDetails, setItemDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [newBid, setNewBid] = useState("");
    const [bids, setBids] = useState([]);
    const [bidError, setBidError] = useState("");
    const [bidCount, setBidCount] = useState(0);
    const [highestBid, setHighestBid] = useState(0);
    const [username, setUsername] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchItemDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8070/item/${id}`);
                setItemDetails(response.data);
            } catch (error) {
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        const fetchOngoingBids = async () => {
            const token = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`http://localhost:8070/item/${id}/bids`,
                    {
                        headers: { 'authToken': token }
                    }  
                );
                const bidAmounts = response.data.map(bid => bid.amount);
                setBids(response.data);
                setBidCount(bidAmounts.length);
                setHighestBid(Math.max(...bidAmounts, 0));
            } catch (error) {
                console.error('Error fetching bids:', error);
            }
        };

        fetchItemDetails();
        fetchOngoingBids();
        let username = localStorage.getItem("username");
        setUsername(username);
    }, [id]);

    const handleBidSubmit = async (e) => {
        const token = localStorage.getItem('authToken');
        e.preventDefault();
        const bidValue = parseFloat(newBid);
        const lastBid = bids.length > 0
            ? Math.max(...bids.map(bid => bid.amount))
            : itemDetails.startingPrice;
        if (bidValue > lastBid) {
            try {
                await axios.post(
                    `http://localhost:8070/item/${id}/bids`, // URL
                    { amount: bidValue, username: username }, // Data to send
                    { headers: { 'authToken': token } } // Headers
                );
                setBids([...bids, {
                    amount: bidValue,
                    username: username
                }]);
                setBidCount(prevCount => prevCount + 1);
                setHighestBid(bidValue); // Update the highest bid directly
                setNewBid("");
                setBidError("");
            } catch (error) {
                setBidError('Error submitting bid');
                navigate("/Login");
            }
        } else {
            setBidError(`Bid must be greater than the last bid of $${lastBid}`);
        }
    };

    if (loading) return <p className="text-center">Loading item details...</p>;
    if (error) return <p className="text-danger text-center">Error: {error}</p>;

    const isAuctionClosed = bidCount >= 10;
    const isHighestBidder = highestBid === (bids.length > 0 ? Math.max(...bids.map(bid => bid.amount)) : 0);

    return (
        <div className="container mt-4">
            <main className="row">
                <div className="col-md-8">
                    {itemDetails ? (
                        <div className="card mb-3">
                            <img src={itemDetails.images[0].data} alt={itemDetails.name} className="card-img-top img-fluid" style={{ width: "50%" }} />
                            <div className="card-body">
                                <h2 className="card-title">{itemDetails.name}</h2>
                                <p className="card-text">{itemDetails.description}</p>
                                <p className="h5 text-primary">
                                    Starting bidding price: <strong>${itemDetails.startingPrice}</strong>
                                </p>
                                <form onSubmit={handleBidSubmit}>
                                    <input
                                        type="number"
                                        value={newBid}
                                        onChange={(e) => setNewBid(e.target.value)}
                                        placeholder="Enter your bid"
                                        className="form-control mb-2"
                                        required
                                        disabled={isAuctionClosed}
                                    />
                                    <button type="submit" className="btn btn-primary" disabled={isAuctionClosed || parseFloat(newBid) <= highestBid}>
                                        Place Bid
                                    </button>
                                </form>
                                {bidError && <p className="text-danger">{bidError}</p>}
                                {isAuctionClosed && isHighestBidder && (
                                    <button className="btn btn-success mt-2">
                                        <Link
                                        to="/payment"
                                        style={
                                            {
                                                textDecoration: 'none',
                                                color:"white"
                                            }
                                        }
                                        >
                                            Buy Item
                                        </Link>
                                    </button>
                                )}
                            </div>
                        </div>
                    ) : (
                        <p>No item details found.</p>
                    )}
                </div>
                <div className="col-md-4">
                    <h2 className="h5 mb-3">Ongoing Bids</h2>
                    <div className="list-group">
                        {bids.length > 0 ? (
                            bids.map((bid, index) => (
                                <a
                                    key={index}
                                    href="#"
                                    className={`list-group-item list-group-item-action ${bid.username === username ? "text-primary fw-semibold" : ""
                                        }`}
                                >
                                    ${bid?.amount}
                                </a>
                               
                            ))
                        ) : (
                            <p className="list-group-item">No ongoing bids</p>
                        )}
                    </div>
                </div>

            </main>
        </div>
    );
};

export default Item;
