import React, { useState, useEffect } from "react";
import { Container, Row, Col, Form, Nav, Button } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Pie } from "react-chartjs-2"; // Import Pie chart

export default function BidderAccount() {
  const [activeTab, setActiveTab] = useState("personal-details");
  const [bidderData, setBidderData] = useState(null);
  const [formData, setFormData] = useState({});
  const navigate = useNavigate(); // Hook for navigation
  const [registeredAuctions, setRegisteredAuctions] = useState([]);
  const [categoryData, setCategoryData] = useState({}); // State for auction categories

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    if (token) {
      axios
        .get("http://localhost:8070/bidder/me", {
          headers: { authToken: token },
        })
        .then((response) => {
          if (response.data) {
            setBidderData(response.data);
            setFormData(response.data);
            fetchRegisteredAuctions(response.data._id);
          }
        })
        .catch((error) => {
          console.error("There was an error fetching the seller data!", error);
        });
    } else {
      console.error("No token found");
    }
  }, []);

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const token = localStorage.getItem("authToken");
    if (token) {
      axios
        .put("http://localhost:8070/bidder/me", formData, {
          headers: { authToken: token },
        })
        .then((response) => {
          setBidderData(response.data);
          setFormData(response.data);
          fetchRegisteredAuctions(response.data._id);
        })
        .catch((error) => {
          console.error("There was an error updating the seller data!", error);
        });
    }
  };

  const fetchRegisteredAuctions = (userId) => {
    const token = localStorage.getItem('authToken');
    axios.post('http://localhost:8070/auction/registered-auctions-Bidder', { userId }, {
        headers: { 'authToken': token }
    })
    .then(response => {
        setRegisteredAuctions(response.data); // Set registered auctions
        prepareCategoryData(response.data); // Prepare category data for pie chart
    })
    .catch(error => {
        console.error("Error fetching registered auctions", error);
    });
  };

  const prepareCategoryData = (auctions) => {
    const categoryCounts = {};

    auctions.forEach(auction => {
      const category = auction.category; // Assuming auction has a category field
      if (category) {
        categoryCounts[category] = (categoryCounts[category] || 0) + 1;
      }
    });

    setCategoryData(categoryCounts);
  };

  const handleLogout = () => {
    const confirmLogout = window.confirm("Do you want to logout?");
    if (confirmLogout) {
      localStorage.removeItem("authToken"); // Remove the token from local storage
      navigate("/ItemListView"); // Navigate to the ItemListView page
    }
  };

  const pieChartData = {
    labels: Object.keys(categoryData),
    datasets: [
      {
        data: Object.values(categoryData),
        backgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE56',
          '#4BC0C0',
          '#9966FF',
          '#FF9F40',
        ],
      },
    ],
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Nav
            variant="tabs"
            activeKey={activeTab}
            onSelect={(selectedKey) => setActiveTab(selectedKey)}
          >
            <Nav.Item>
              <Nav.Link eventKey="personal-details">Personal details</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="registered-auction">Registered auction</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="edit-profile">Edit profile</Nav.Link>
            </Nav.Item>
          </Nav>
          <div className="card mt-4 p-4" style={{ marginBottom: 90 }}>
            {activeTab === "personal-details" && bidderData && (
              <>
                <h3 className="text-center mb-4">Bidder Personal Details</h3>
                <div className="text-center">
                  <img
                    src="/Assests/defaultprofile.jpg"
                    alt="Profile"
                    className="rounded-circle mb-4"
                    style={{
                      width: "150px",
                      height: "150px",
                      backgroundColor: "#f0f0f0",
                    }}
                  />
                </div>
                <Form>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Email :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={bidderData.email}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Name :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={`${bidderData.firstName} ${bidderData.lastName}`}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Address :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={bidderData.address}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Birth Day :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={new Date(bidderData.birthday).toLocaleDateString()}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Phone Number :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={bidderData.contactInfo}
                      />
                    </Col>
                  </Form.Group>
                  {/* Logout Button */}
                  <div className="text-center mt-4">
                    <Button variant="danger" onClick={handleLogout}>
                      Logout
                    </Button>
                    <Button variant="primary">
                      <a
                        href="/myorders"
                        style={{
                          color: "white",
                          textDecoration: "none",
                        }}
                      >
                        my orders
                      </a>
                    </Button>
                  </div>
                  <a href="/Admin">Admin?</a>
                </Form>
              </>
            )}
            {activeTab === 'registered-auction' && registeredAuctions.length > 0 && (
              <div>
                <h5>Registered Auctions</h5>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>Starting Date & Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registeredAuctions.map(auction => {
                      const formattedDate = new Date(auction.startingDateTime).toLocaleString(); // Format the date and time
                      return (
                        <tr key={auction._id}>
                          <td>{auction.title}</td>
                          <td>{formattedDate}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                <br/><br/>
                <h5>Auction Categories Distribution</h5>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '300px' }}>
                  <Pie data={pieChartData} options={{ maintainAspectRatio: false }} height={150} width={150} />
                </div>
              </div>
            )}
            {activeTab === "edit-profile" && bidderData && (
              <>
                <Form onSubmit={handleSubmit}>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Email :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>First Name :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Last Name :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Address :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Phone Number :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="contactInfo"
                        value={formData.contactInfo}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Birthday :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="date"
                        name="birthday"
                        value={formData.birthday.split("T")[0]}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <div className="text-center">
                    <Button variant="primary" type="submit">
                      Update Profile
                    </Button>
                  </div>
                </Form>
              </>
            )}
          </div>
        </Col>
      </Row>
    </Container>
  );
}