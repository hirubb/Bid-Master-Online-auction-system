import React, { useState, useEffect } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import 'bootstrap/dist/css/bootstrap.min.css';

export default function EmployeeSignup() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    jobTitle: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState(""); // State for search term
  const [logo, setLogo] = useState("");

  // Handle input changes with validation for Full Name, Job Title, and Email
  const handleChange = (e) => {
    const { name, value } = e.target;

    // Allow only letters for fullName and jobTitle
    if (name === "fullName" || name === "jobTitle") {
      const lettersOnly = /^[A-Za-z\s]+$/;
      if (value === "" || lettersOnly.test(value)) {
        setFormData({ ...formData, [name]: value });
      }
    } 
    // Allow only lowercase letters, @, and . for email
    else if (name === "email") {
      const emailPattern = /^[a-z@.]+$/;
      if (value === "" || emailPattern.test(value)) {
        setFormData({ ...formData, [name]: value });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      await axios.post("http://localhost:8070/employee", formData);
      alert("Employee Added Successfully!");
      setFormData({ fullName: "", email: "", jobTitle: "" }); // Reset form
      fetchEmployees(); // Refresh employee list immediately
    } catch (err) {
      console.error(err);
      setError("Failed to add employee.");
    } finally {
      setLoading(false);
    }
  };

  // Fetch all employees
  const fetchEmployees = async () => {
    try {
      const response = await axios.get("http://localhost:8070/employee");
      setEmployees(response.data.employees); // Assuming data is in employees array
    } catch (error) {
      console.error(error);
    }
  };

  // Delete employee by ID
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8070/employee/${id}`);
      fetchEmployees(); // Refresh employee list after delete
      alert("Employee deleted successfully!");
    } catch (error) {
      console.error(error);
    }
  };

  // Generate PDF report
  const generateReport = () => {
    const filteredEmployees = employees.filter(employee => 
      employee.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.jobTitle.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const doc = new jsPDF();

    // Add company logo
    if (logo) {
      doc.addImage(logo, 'PNG', 80, 10, 50, 50, undefined, 'FAST'); // Adjust size and position
    }

    // Add company details
    doc.setFontSize(10);
    doc.text("Call us : +94 xxxxxxxxx", 15, 60);
    doc.text("Mail us : bidmaster@gmail.com", 15, 68);
    doc.text("Find us : Arcade Independence Square, Colombo 07, Sri Lanka", 15, 76);
    
    // Add a title
    doc.setFontSize(16);
    doc.text("Employees Report", 14, 92);
    
    // Add table
    autoTable(doc, {
      startY: 97,
      head: [['Full Name', 'Email', 'Job Title']],
      body: filteredEmployees.map(employee => [
        employee.fullName,
        employee.email,
        employee.jobTitle,
      ]),
    });

    doc.save('employees_report.pdf');
  };

  // Filter employees based on search term
  const filteredEmployees = employees.filter(
    (employee) =>
      employee.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.jobTitle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Fetch employees on component mount
  useEffect(() => {
    fetchEmployees();
    const fetchLogo = async () => {
      const response = await fetch("/Assests/bid-master-logo-zip-file/png/logo-black.png"); // Adjust path as necessary
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogo(reader.result);
      };
      reader.readAsDataURL(blob);
    };
    fetchLogo();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Add Employee</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Full Name</label>
          <input
            type="text"
            name="fullName"
            className="form-control"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Job Title</label>
          <input
            type="text"
            name="jobTitle"
            className="form-control"
            value={formData.jobTitle}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? "Adding..." : "Add Employee"}
        </button>
      </form>

      {/* Search bar */}
      <h2 className="mt-5">Employee List</h2>
      <input
        type="text"
        className="form-control mb-3"
        placeholder="Search by Full Name or Job Title"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)} // Update search term on input change
      />

      <table className="table mt-3">
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Job Title</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.length > 0 ? (
            filteredEmployees.map((employee) => (
              <tr key={employee._id}>
                <td>{employee.fullName}</td>
                <td>{employee.email}</td>
                <td>{employee.jobTitle}</td>
                <td>
                  <button
                    onClick={() => handleDelete(employee._id)}
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center" style={{ color: 'red' }}>
                Your search result is not found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <div className="d-flex justify-content-center mt-4">
        <button
          style={{
            backgroundColor: "blue",
            color: "white",
            padding: "10px 20px",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
            marginRight: "10px", // Small space between buttons
          }}
          onClick={generateReport} // Button to generate report
        >
          Generate Report
        </button>

        <button
          style={{
            backgroundColor: "black",
            color: "white",
            padding: "10px 20px",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          <a
            href="/salaryTable"
            style={{
              textDecoration: "none",
              color: "white",
            }}
          >
            Calculate Salary
          </a>
        </button>
      </div>
    </div>
  );
}