import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function BidderSignUp() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    username: "",
    password: "",
    address: "",
    contactInfo: "+94",
    birthday: "",
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "email") {
      setFormData({ ...formData, [name]: value.toLowerCase() });
    } else {
      setFormData({ ...formData, [name]: value });
    }
    validateField(name, value);
  };

  const handleKeyPress = (e) => {
    const { name } = e.target;

    // Allowing only specific inputs for the contact number
    if (name === "contactInfo") {
      const currentValue = formData.contactInfo;
      const value = currentValue; 
    
      // Allow first value to be +94 or 0
      if (currentValue.length === 3) {
        if (currentValue === "+94") {
          // Disable keys that are not 7/0
          if (!/7/.test(e.key)) {
            e.preventDefault();
          }
        } else if (currentValue === "0") {
          // Disable keys that are not 7/0
          if (!/7/.test(e.key)) {
            e.preventDefault();
          }
        }
      }
    
      if (value.length === 0 && e.key === '+') {
        return; // Allow the '+' sign as the first character
      }
    
      // Only allow numbers 0-9 after the prefix
      if (!/[0-9]/.test(e.key)) {
        e.preventDefault();
      }
    
      // After +94 or 0, only allow 70/71/72/74/75/76/77/78
      if (currentValue.length === 4) {
        if (!/(70|71|72|74|75|76|77|78)/.test(currentValue + e.key)) {
          e.preventDefault();
        }
      }
    }    
    
    if (name === "email") {
      if (!/[a-z0-9@.]/.test(e.key)) {
        e.preventDefault();
      }
    }
    if (
      (name === "firstName" || name === "lastName") &&
      !/[a-zA-Z\s]/.test(e.key)
    ) {
      e.preventDefault();
    }
    if (name === "address") {
      if (!/[a-zA-Z0-9/.,\s]/.test(e.key)) {
        e.preventDefault();
      }
    }
  };

  const validateField = (name, value) => {
    let fieldErrors = { ...errors };

    switch (name) {
      case "firstName":
      case "lastName":
        fieldErrors[name] = value.match(/^[a-zA-Z\s]+$/) ? "" : "";
        break;
      case "email":
        fieldErrors.email = ""; 
        break;
      case "password":
        fieldErrors.password = value.length >= 6 ? "" : "";
        break;
      case "contactInfo":
        // Validation logic has been handled in handleKeyPress
        break;
      case "birthday":
        const today = new Date();
        const birthDate = new Date(value);
        const age = today.getFullYear() - birthDate.getFullYear();
        const isFutureDate = birthDate > today;
        fieldErrors.birthday = (age >= 16 && !isFutureDate) ? "" : "";
        break;
      case "address":
        fieldErrors.address =
          value.length > 0 && value.length <= 100 && /^[a-zA-Z0-9/.,\s]+$/.test(value)
            ? ""
            : "";
        break;
      default:
        fieldErrors[name] = value ? "" : "";
        break;
    }

    setErrors(fieldErrors);
  };

  const today = new Date().toISOString().split("T")[0];

  // Set max date to 16 years ago from today
  const maxDate = new Date();
  maxDate.setFullYear(maxDate.getFullYear() - 16);
  const maxDateString = maxDate.toISOString().split("T")[0];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (Object.values(errors).some((error) => error !== "")) {
      alert("Please fix the errors in the form before submitting.");
      return;
    }
    axios
      .post("http://localhost:8070/bidder/add", formData)
      .then((response) => {
        if (response.data === "exist") {
          alert("User already exists");
        } else {
          alert("Bidder Added Successfully!");
          navigate("/Login");

          setFormData({
            firstName: "",
            lastName: "",
            email: "",
            username: "",
            password: "",
            address: "",
            contactInfo: "+94",
            birthday: "",
          });
        }
      })
      .catch((error) => {
        console.error("There was an error adding the seller!", error);
      });
  };

  return (
    <div className="container mt-5 seller-signup-container">
      <h2>Bidder Registration</h2>
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="firstName">First Name</label>
            <input
              type="text"
              className="form-control"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onKeyDown={handleKeyPress}
              onChange={handleChange}
              required
            />
            {errors.firstName && (
              <div className="text-danger">{errors.firstName}</div>
            )}
          </div>
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="lastName">Last Name</label>
            <input
              type="text"
              className="form-control"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onKeyDown={handleKeyPress}
              onChange={handleChange}
              required
            />
            {errors.lastName && (
              <div className="text-danger">{errors.lastName}</div>
            )}
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              className="form-control"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              onKeyPress={handleKeyPress}
              required
            />
            {/* No error message for email */}
          </div>
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="contactInfo">Mobile Number</label>
            <input
              type="text"
              className="form-control"
              id="contactInfo"
              name="contactInfo"
              onKeyPress={handleKeyPress}
              maxLength={12} // +94 + 9 digits
              placeholder="Enter number starting with +94"
              value={formData.contactInfo}
              onChange={handleChange}
              required
            />
            {/* No error message for contactInfo */}
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="gender">Gender</label>
            <select
              className="form-control"
              id="gender"
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              required
            >
              <option value="">Select</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Not Disclose">Not Disclose</option>
            </select>
            {errors.gender && (
              <div className="text-danger">{errors.gender}</div>
            )}
          </div>
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="birthday">Date of Birth</label>
            <input
              type="date"
              className="form-control"
              id="birthday"
              name="birthday"
              value={formData.birthday}
              onChange={handleChange}
              max={maxDateString} 
              required
            />
            {errors.birthday && (
              <div className="text-danger">{errors.birthday}</div>
            )}
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 mb-3 form-group">
            <label htmlFor="address">Address</label>
            <input
              type="text"
              className="form-control"
              id="address"
              name="address"
              value={formData.address}
              onKeyDown={handleKeyPress}
              onChange={handleChange}
              required
            />
            {errors.address && (
              <div className="text-danger">{errors.address}</div>
            )}
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              className="form-control"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              required
            />
            {/* No error message for username */}
          </div>
          <div className="col-md-6 mb-3 form-group">
            <label htmlFor="password">Password</label>
          <input
              type="password"
              className="form-control"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
            />
            {/* No error message for password */}
          </div>
        </div>
        <button type="submit" className="btn btn-primary">
          Register
        </button>
      </form>
    </div>
  );
}