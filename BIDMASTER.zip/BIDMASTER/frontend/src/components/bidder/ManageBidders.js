import React, { useEffect, useState } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import 'bootstrap/dist/css/bootstrap.min.css';

export default function ManageBidders() {
    const [bidders, setBidders] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [logo, setLogo] = useState("");

    useEffect(() => {
        const fetchBidders = async () => {
            try {
                const response = await axios.get("http://localhost:8070/bidder/all");
                setBidders(response.data);
            } catch (error) {
                console.error("Error fetching bidders:", error);
            }
        };

        const fetchLogo = async () => {
            const response = await fetch("/Assests/bid-master-logo-zip-file/png/logo-black.png"); // Adjust path as necessary
            const blob = await response.blob();
            const reader = new FileReader();
            reader.onloadend = () => {
                setLogo(reader.result);
            };
            reader.readAsDataURL(blob);
        };

        fetchBidders();
        fetchLogo();
    }, []);

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:8070/bidder/delete/${id}`);
            setBidders(bidders.filter(bidder => bidder._id !== id));
        } catch (error) {
            console.error("Error deleting bidder:", error);
        }
    };

    const generateReport = () => {
        const filteredBidders = bidders.filter(bidder => 
            bidder.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            bidder.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            bidder.email.toLowerCase().includes(searchTerm.toLowerCase())
        );

        const doc = new jsPDF();
        
        // Add company logo
        if (logo) {
            doc.addImage(logo, 'PNG', 80, 10, 50, 50, undefined, 'FAST'); // Adjust size and position
        }

        // Add company details
        doc.setFontSize(10);
        doc.text("Call us : +94 xxxxxxxxx", 15, 60);
        doc.text("Mail us : bidmaster@gmail.com", 15, 68);
        doc.text("Find us : Arcade Independence Square, Colombo 07, Sri Lanka", 15, 76);
        
        // Add a title
        doc.setFontSize(16);
        doc.text("Bidders Report", 14, 92);
        
        // Add table
        autoTable(doc, {
            startY: 97,
            head: [['First Name', 'Last Name', 'Email', 'Address', 'Contact Info', 'Birthday']],
            body: filteredBidders.map(bidder => [
                bidder.firstName,
                bidder.lastName,
                bidder.email,
                bidder.address,
                bidder.contactInfo,
                formatDate(bidder.birthday),
            ]),
        });

        doc.save('bidders_report.pdf');
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString(); // Format the date as "MM/DD/YYYY" 
    };

    const filteredBidders = bidders.filter(bidder => 
        bidder.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bidder.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bidder.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="container mt-5">
            <h1 className="mb-4">Manage Bidders</h1>
            {/* Search */}
            <div className="mb-3 d-flex align-items-center">
                <input 
                    type="text" 
                    placeholder="Search..." 
                    className="form-control me-2" 
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)} 
                />
                <button className="btn btn-primary" onClick={generateReport}>
                    Generate Report
                </button>
            </div>
            
            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Contact Info</th>
                        <th>Birthday</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredBidders.length > 0 ? (
                        filteredBidders.map(bidder => (
                            <tr key={bidder._id}>
                                <td>{bidder.firstName}</td>
                                <td>{bidder.lastName}</td>
                                <td>{bidder.email}</td>
                                <td>{bidder.address}</td>
                                <td>{bidder.contactInfo}</td>
                                <td>{formatDate(bidder.birthday)}</td>
                                <td>
                                    <button 
                                        className="btn btn-danger"
                                        onClick={() => handleDelete(bidder._id)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="7" className="text-center" style={{ color: 'red' }}>Your search result is not found.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}