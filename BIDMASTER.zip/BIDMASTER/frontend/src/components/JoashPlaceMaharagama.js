import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Tooltip } from 'react-tooltip';

const JoashPlaceMaharagama = () => {
  const [seats, setSeats] = useState([]);
  const [seatLayout, setSeatLayout] = useState([]);
  const [numRows, setNumRows] = useState(() => {
    const savedRows = localStorage.getItem('numRows_JoashPlace');
    return savedRows ? parseInt(savedRows, 10) : 5;
  });
  const [numColumns, setNumColumns] = useState(() => {
    const savedCols = localStorage.getItem('numColumns_JoashPlace');
    return savedCols ? parseInt(savedCols, 10) : 10;
  });

  const fetchSeats = async () => {
    try {
      const response = await axios.get('http://localhost:8070/test1/seats');
      const filteredSeats = response.data.filter(seat => seat.location === 'Joash Place Maharagama');
      setSeats(filteredSeats);
      generateSeatLayout(filteredSeats, numRows, numColumns);
    } catch (error) {
      console.error('Error fetching Joash Place Maharagama seats:', error);
    }
  };

  const generateSeatLayout = (seatsData, rows, columns) => {
    const layout = Array.from({ length: rows }, (_, rowIndex) => {
      return Array.from({ length: columns }, (_, colIndex) => {
        const seatId = String.fromCharCode(65 + rowIndex) + (colIndex + 1);
        const seatData = seatsData.find(seat => seat.seatId === seatId);
        return {
          seatId,
          isOccupied: !!seatData,
          bidderName: seatData ? seatData.name : '',
        };
      });
    });
    setSeatLayout(layout);
  };

  const addRow = () => {
    setNumRows(prevRows => {
      const newRowCount = prevRows + 1;
      localStorage.setItem('numRows_JoashPlace', newRowCount);
      generateSeatLayout(seats, newRowCount, numColumns);
      return newRowCount;
    });
  };

  const removeRow = () => {
    if (numRows > 1) {
      setNumRows(prevRows => {
        const newRowCount = prevRows - 1;
        localStorage.setItem('numRows_JoashPlace', newRowCount);
        generateSeatLayout(seats, newRowCount, numColumns);
        return newRowCount;
      });
    }
  };

  const addColumn = () => {
    setNumColumns(prevCols => {
      const newColCount = prevCols + 1;
      localStorage.setItem('numColumns_JoashPlace', newColCount);
      generateSeatLayout(seats, numRows, newColCount);
      return newColCount;
    });
  };

  const removeColumn = () => {
    if (numColumns > 1) {
      setNumColumns(prevCols => {
        const newColCount = prevCols - 1;
        const updatedSeats = seats
          .map(seat => {
            const seatId = seat.seatId;
            const rowPart = seatId.charAt(0);
            const colPart = parseInt(seatId.slice(1), 10);
            const newColPart = colPart <= newColCount ? colPart : newColCount;

            return {
              ...seat,
              seatId: `${rowPart}${newColPart}`,
            };
          })
          .filter(seat => parseInt(seat.seatId.slice(1), 10) <= newColCount);

        localStorage.setItem('numColumns_JoashPlace', newColCount);
        generateSeatLayout(updatedSeats, numRows, newColCount);
        return newColCount;
      });
    }
  };

  useEffect(() => {
    fetchSeats();
  }, []);

  useEffect(() => {
    generateSeatLayout(seats, numRows, numColumns);
  }, [numRows, numColumns, seats]);

  // Calculate seat counts
  const totalSeats = numRows * numColumns;
  const occupiedSeats = seats.length;
  const availableSeats = totalSeats - occupiedSeats;

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>Seating Plan - Joash Place Maharagama</h2>

      {/* Seat count display */}
      <div style={seatCountStyle}>
        <span>Total Seats: {totalSeats}</span>
        <span>Occupied: {occupiedSeats}</span>
        <span>Available: {availableSeats}</span>
      </div>

      <div style={{ ...seatingContainerStyle, gridTemplateColumns: `repeat(${numColumns + 1}, 60px)` }}>
        <div style={emptyCellStyle}></div>
        {Array.from({ length: numColumns }, (_, colIndex) => (
          <div key={colIndex} style={columnLabelStyle}>
            {colIndex + 1}
          </div>
        ))}
        {seatLayout.map((row, rowIndex) => (
          <React.Fragment key={rowIndex}>
            <div style={rowLabelStyle}>
              {String.fromCharCode(65 + rowIndex)}
            </div>
            {row.map(seat => (
              <div
                key={seat.seatId}
                style={seatStyle(seat.isOccupied)}
                data-tooltip-id={seat.seatId}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                onClick={() => alert(`Seat ${seat.seatId} clicked`)}
              >
                {seat.seatId}
                <Tooltip id={seat.seatId} style={tooltipStyle}>
                  {seat.isOccupied ? `Assigned to ${seat.bidderName}` : 'Available'}
                </Tooltip>
              </div>
            ))}
          </React.Fragment>
        ))}
      </div>

      <div style={buttonContainerStyle}>
        <button onClick={addRow} style={buttonStyle}>Add Row</button>
        <button onClick={removeRow} style={{ ...buttonStyle, backgroundColor: '#dc3545' }}>Remove Row</button>
        <button onClick={addColumn} style={buttonStyle}>Add Column</button>
        <button onClick={removeColumn} style={{ ...buttonStyle, backgroundColor: '#dc3545' }}>Remove Column</button>
      </div>
    </div>
  );
};

const containerStyle = {
  padding: '20px',
  background: 'linear-gradient(135deg, #e0f7fa, #c8e6c9)',
  maxWidth: '1000px',
  margin: '0 auto',
  borderRadius: '20px',
  boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
};

const headerStyle = {
  color: '#004d40',
  marginBottom: '20px',
  fontSize: '28px',
  fontWeight: 'bold',
  textAlign: 'center',
  paddingBottom: '10px',
  borderBottom: '2px solid #004d40',
};

const seatCountStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  marginBottom: '20px',
  fontSize: '18px',
  color: '#004d40',
  fontWeight: 'bold',
};

const buttonContainerStyle = {
  marginTop: '20px',
  display: 'flex',
  justifyContent: 'center',
  gap: '15px',
};

const buttonStyle = {
  backgroundColor: '#007bff',
  color: 'white',
  padding: '10px 20px',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
  transition: 'background-color 0.3s',
};

const seatingContainerStyle = {
  display: 'grid',
  gap: '10px',
  justifyContent: 'center',
  alignItems: 'center',
};

const seatStyle = (isOccupied) => ({
  width: '60px',
  height: '60px',
  backgroundColor: isOccupied ? '#dc3545' : '#28a745',
  color: '#fff',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  fontSize: '16px',
  fontWeight: 'bold',
  borderRadius: '10px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  transition: 'transform 0.2s ease',
  cursor: 'pointer',
});

const emptyCellStyle = {
  width: '60px',
  height: '60px',
};

const columnLabelStyle = {
  fontWeight: 'bold',
  textAlign: 'center',
};

const rowLabelStyle = {
  fontWeight: 'bold',
  textAlign: 'center',
};

const tooltipStyle = {
  backgroundColor: '#333',
  color: '#fff',
  padding: '8px 12px',
  borderRadius: '5px',
  fontSize: '14px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.3)',
};

export default JoashPlaceMaharagama;
