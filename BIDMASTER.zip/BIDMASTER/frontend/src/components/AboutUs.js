import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";

export default function AboutUs() {
    return (
        <Container className="mt-5">
            <Row>
                <Col md={12}>
                    <Card>
                        <Card.Body>
                            <Card.Title className="text-center">About Us</Card.Title>
                            <Card.Text>
                                Welcome to <strong>Bid Master</strong>, your premier auction system located in the heart of Arcade Independence Square, Colombo 07, Sri Lanka. At Bid Master, we specialize in three unique categories: <strong>ARTs</strong>, <strong>Collectibles</strong>, and <strong>Jewelleries</strong>.
                            </Card.Text>
                            <Card.Text>
                                Our mission is to connect buyers and sellers in a dynamic marketplace that fosters excitement and creativity. Whether you're looking to find the perfect piece of art, add to your collectible collection, or discover exquisite jewellery, Bid Master is here to facilitate a seamless auction experience.
                            </Card.Text>
                            <Card.Text>
                                Join us as we celebrate the art of bidding and the beauty of unique items. Explore our categories and take part in the vibrant world of auctions at Bid Master!
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}
