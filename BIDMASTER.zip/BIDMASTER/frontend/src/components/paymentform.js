import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const PaymentForm = () => {
    const [formData, setFormData] = useState({
        cardType: '',
        cardNumber: '',
        expirationMonth: '',
        expirationYear: '',
        cvv: '',
        fullName: '',
        email: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
    });

    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const navigate = useNavigate(); // Initialize useNavigate

    const handleChange = (e) => {
        const { name, value } = e.target;

        // Validate fullName, city, and state to allow only letters and spaces
        const lettersOnly = /^[A-Za-z\s]*$/;
        if ((name === 'fullName' || name === 'city' || name === 'state') && !lettersOnly.test(value)) return;

        // Validate email to allow only lowercase letters, digits, @, comma, and dot
        if (name === 'email') {
            const emailRegex = /^[a-z0-9@.,]+$/;
            if (!emailRegex.test(value)) return; // Reject invalid characters
        }

        // Validate address to allow only letters, numbers, spaces, and commas
        if (name === 'address') {
            const addressRegex = /^[A-Za-z0-9\s,]*$/;
            if (!addressRegex.test(value)) return; // Reject invalid characters
        }

        // Validate zipCode to allow only 5 digits
        if (name === 'zipCode') {
            const zipCodeRegex = /^[0-9]{0,5}$/; // Allows 0 to 5 digits
            if (!zipCodeRegex.test(value)) return; // Reject invalid characters
        }

        // Validate expirationMonth to allow only numbers from 1 to 12
        if (name === 'expirationMonth') {
            const monthRegex = /^(1[0-2]|[1-9])?$/; // Allows 1-12 or empty
            if (!monthRegex.test(value)) return; // Reject invalid month input
        }

        // Validate expirationYear to allow only 4-digit numerics
        if (name === 'expirationYear') {
            const yearRegex = /^[0-9]{0,4}$/; // Allows 0 to 4 digits
            if (!yearRegex.test(value)) return; // Reject invalid year input
        }

        // Validate CVV to allow only 3 digits
        if (name === 'cvv') {
            const cvvRegex = /^[0-9]{0,3}$/; // Allows 0 to 3 digits
            if (!cvvRegex.test(value)) return; // Reject invalid characters
        }

        // Validate cardNumber to allow only 16 digits
        if (name === 'cardNumber') {
            const cardNumberRegex = /^[0-9]{0,16}$/; // Allows 0 to 16 digits
            if (!cardNumberRegex.test(value)) return; // Reject invalid characters
        }

        setFormData({ ...formData, [name]: value });
    };

    const validateForm = () => {
        const { cardNumber, expirationMonth, expirationYear, cvv, fullName, email, address, city, state, zipCode } = formData;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Standard email format validation
        let errors = {};

        // Updated card number validation
        if (cardNumber.length !== 16 || isNaN(cardNumber)) {
            errors.cardNumber = 'Card number must be exactly 16 digits'; // Adjusted error message
        }
        if (cvv.length !== 3 || isNaN(cvv)) {
            errors.cvv = 'CVV must be exactly 3 digits'; // Updated error message for CVV
        }
        if (!emailRegex.test(email)) {
            errors.email = 'Invalid email format';
        }
        if (fullName.trim() === '') {
            errors.fullName = 'Full name is required';
        }
        if (address.trim() === '') {
            errors.address = 'Address is required';
        }
        if (city.trim() === '') {
            errors.city = 'City is required';
        }
        if (state.trim() === '') {
            errors.state = 'State is required';
        }
        if (zipCode.length !== 5 || isNaN(zipCode)) {
            errors.zipCode = 'Zip code must be exactly 5 digits';
        }

        return errors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccessMessage('');

        const errors = validateForm();
        if (Object.keys(errors).length > 0) {
            Object.keys(errors).forEach((field) => {
                alert(errors[field]);
            });
            return;
        }

        try {
            const response = await axios.post(
                'http://localhost:8070/payment/add',
                formData,
                { headers: { 'Content-Type': 'application/json' } }
            );

            setSuccessMessage(response.data.message);

            // Clear form
            setFormData({
                cardType: '',
                cardNumber: '',
                expirationMonth: '',
                expirationYear: '',
                cvv: '',
                fullName: '',
                email: '',
                address: '',
                city: '',
                state: '',
                zipCode: ''
            });

            // Navigate to /payments after successful form submission
            navigate('/payments');

        } catch (err) {
            setError(err.response?.data?.message || 'Error processing payment');
        }
    };

    const cardTypes = [
        { name: 'Visa', imgSrc: 'https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg' },
        { name: 'Mastercard', imgSrc: 'https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg' },
        { name: 'American Express', imgSrc: 'https://upload.wikimedia.org/wikipedia/commons/3/30/American_Express_logo.svg' },
        { name: 'Discover', imgSrc: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Commons-logo-en.svg/1556px-Commons-logo-en.svg.png' },
        { name: 'JCB', imgSrc: 'https://www.fintechfutures.com/files/2018/01/JCB-620x400.jpg' }
    ];

    return (
        <div style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100vh',  // Ensures container fills the height of the viewport
            backgroundColor: '#e0f7fa'
        }}>
            <div style={{
                margin: '20px',
                maxWidth: '600px',
                padding: '20px',
                border: '1px solid #ddd',
                borderRadius: '10px',
                boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                backgroundColor: '#f9f9f9'
            }}>
                <h1 style={{ textAlign: 'center', color: '#333' }}>Payment Gateway</h1>
                {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
                {successMessage && <p style={{ color: 'green', textAlign: 'center' }}>{successMessage}</p>}
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '10px' }}>
                        <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>Card Type:</label>
                        <select
                            name="cardType"
                            value={formData.cardType}
                            onChange={handleChange}
                            required
                            style={{
                                display: 'block',
                                width: '100%',
                                padding: '10px',
                                borderRadius: '5px',
                                border: '1px solid #ddd',
                                fontSize: '16px'
                            }}
                        >
                            <option value="">Select Card Type</option>
                            {cardTypes.map((card) => (
                                <option key={card.name} value={card.name}>
                                    {card.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                        {cardTypes.map((card) => (
                            <div key={card.name} style={{ textAlign: 'center' }}>
                                <img src={card.imgSrc} alt={card.name} style={{ width: '50px', height: 'auto' }} />
                                <p style={{ fontSize: '12px' }}>{card.name}</p>
                            </div>
                        ))}
                    </div>

                    {[{ label: 'Card Number', name: 'cardNumber', type: 'text' },
                    { label: 'Expiration Month', name: 'expirationMonth', type: 'number' },
                    { label: 'Expiration Year', name: 'expirationYear', type: 'text' },  // Change type to text for 4-digit input
                    { label: 'CVV', name: 'cvv', type: 'text' },
                    { label: 'Full Name', name: 'fullName', type: 'text' },
                    { label: 'Email', name: 'email', type: 'email' },
                    { label: 'Address', name: 'address', type: 'text' },
                    { label: 'City', name: 'city', type: 'text' },
                    { label: 'State', name: 'state', type: 'text' },
                    { label: 'Zip Code', name: 'zipCode', type: 'text' }
                    ].map(({ label, name, type }) => (
                        <div key={name} style={{ marginBottom: '10px' }}>
                            <label style={{ fontWeight: 'bold', display: 'block', marginBottom: '5px' }}>{label}:</label>
                            <input
                                name={name}
                                type={type}
                                value={formData[name]}
                                onChange={handleChange}
                                required
                                style={{
                                    width: '100%',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd',
                                    fontSize: '16px'
                                }}
                            />
                        </div>
                    ))}

                    <button
                        type="submit"
                        style={{
                            width: '100%',
                            padding: '10px',
                            borderRadius: '5px',
                            border: 'none',
                            backgroundColor: '#007BFF',
                            color: '#fff',
                            fontSize: '16px',
                            cursor: 'pointer'
                        }}
                    >
                        Submit Payment
                    </button>
                </form>
            </div>
        </div>
    );
};

export default PaymentForm;