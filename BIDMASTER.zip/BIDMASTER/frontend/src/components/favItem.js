import React, { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import axios from "axios";

export default function FavItem({}) {
  // Function to handle favorite/unfavorite
 const [favorites, setFavorites] = useState([]);
 const [loading,setLoading] = useState(false);
 const location = useLocation();

  const getQueryParams = () => {
    const query = new URLSearchParams(location.search);
    return {
      search: query.get("search") || "",
      category: query.get("category") || "",
      minPrice: query.get("minPrice") || "",
      maxPrice: query.get("maxPrice") || "",
      isFavourite: query.get(true) || ""
    };
  };

  useEffect(()=> {
    let fetchFavouriteItem = () => {
      let username = localStorage.getItem('username') || null;
      const { search, category, minPrice, maxPrice, isFavourite } = getQueryParams();
      setLoading(true);
      axios
        .get("http://localhost:8070/item", {
          params: { search, category, minPrice, maxPrice, username, isFavourite  },
        })
        .then((response) => {          
          if(response.data.length > 0) {
            setFavorites(response.data.filter((item) => item.isFavourite)); 
            console.log("#$ isfavourtie", response.data.filter((item) => item.isFavourite === true))
          }
          
          setLoading(false);
        })
        .catch((error) => {
          console.error("There was an error fetching the items!", error);
          setLoading(false);
        });
    };
    fetchFavouriteItem();
  }, [])
  const handleFavoriteToggle = async (item) => {
    try {
      const token = localStorage.getItem("authToken"); // Get auth token
      const response = await axios.post(
        "http://localhost:8070/favItem",
        { itemId: item._id } // Send the item ID to backend
        ,{ headers: { Authorization: `Bearer ${token}` } } // Add token in headers
      );

      // Update the favorites state based on backend response
      if (response.data.success) {
        // Update the local state (add or remove from favorites)
        if (favorites.some((fav) => fav._id === item._id)) {
          setFavorites(favorites.filter((fav) => fav._id !== item._id)); // Remove from favorites
        } else {
          setFavorites([...favorites, item]); // Add to favorites
        }
      }
    } catch (error) {
      console.error("Error updating favorites", error);
    }
  };
  return (
    <div className="container mt-5">
      <h1>Favorite Items</h1>
      {favorites?.length === 0 ? (
        <p>No favorite items.</p>
      ) : (
        <div className="row">
          {favorites?.length > 0 && favorites.map((item) => (
            <div key={item._id} className="col-md-3 mb-4">
              <div className="card h-100">
                <img
                  src={item.images[0]?.data || "placeholder-image-url"}
                  alt={item.name}
                  className="card-img-top"
                  style={{
                    width: "100%",
                    height: "200px",
                    objectFit: "cover",
                    backgroundColor: "#f0f0f0",
                  }}
                />
                <div className="card-body">
                  <h5 className="card-title">{item.name}</h5>
                  <p className="card-text">{item.description}</p>
                  <p className="card-text">
                    <strong>Category:</strong> {item.category}
                  </p>
                  <p className="card-text">
                    <strong>Brand:</strong> {item.brand}
                  </p>
                  <p className="card-text">
                    <strong>Starting Price:</strong> ${item.startingPrice}
                  </p>
                  <button className="btn btn-dark" type="submit">
                    <Link
                      to={`/Item/${item._id}`}
                      className="text-white text-decoration-none"
                    >
                      View Item
                    </Link>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
