import React, { useEffect, useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

export default function ManageSellers() {
    const [sellers, setSellers] = useState([]);
    const [searchQuery, setSearchQuery] = useState(""); // State for the search query

    useEffect(() => {
        const fetchSellers = async () => {
            try {
                const response = await axios.get("http://localhost:8070/seller/all");
                setSellers(response.data);
            } catch (error) {
                console.error("Error fetching sellers:", error);
            }
        };
        fetchSellers();
    }, []);

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:8070/seller/delete/${id}`);
            setSellers(sellers.filter(seller => seller._id !== id));
        } catch (error) {
            console.error("Error deleting seller:", error);
        }
    };

    // Filter sellers based on the search query (name or email)
    const filteredSellers = sellers.filter((seller) =>
        seller.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        seller.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        seller.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="container mt-5">
            <h1 className="mb-4">Manage Sellers</h1>

            {/* Search bar */}
            <input
                type="text"
                className="form-control mb-3"
                placeholder="Search by name or email"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)} // Update search query
            />

            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Telephone</th>
                        <th>Company</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredSellers.map(seller => (
                        <tr key={seller._id}>
                            <td>{seller.firstName}</td>
                            <td>{seller.lastName}</td>
                            <td>{seller.email}</td>
                            <td>{seller.address}</td>
                            <td>{seller.contactInfo}</td>
                            <td>{seller.companyName}</td>
                            <td>
                                <button
                                    className="btn btn-danger"
                                    onClick={() => handleDelete(seller._id)}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
