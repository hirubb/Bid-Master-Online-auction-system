import React, { useState, useEffect } from "react";
import { Container, Row, Col, Form, Nav, Button } from "react-bootstrap";
import axios from "axios";

import { Link, useNavigate } from 'react-router-dom';

import { Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale, // Import LinearScale for Bar charts
  BarElement,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import QRCode from "qrcode";
import jsPDF from "jspdf";
import "jspdf-autotable"; // Import for table generation

// Register the elements
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement
);


export default function SellerAccount() {
  const [activeTab, setActiveTab] = useState("personal-details");
  const [sellerData, setSellerData] = useState(null);
  const [formData, setFormData] = useState({});
  const navigate = useNavigate(); // Hook for navigation

  const [registeredAuctions, setRegisteredAuctions] = useState([]);
  const mostRegisteredAuctions = [
    { title: "High place Jewellery auction", registeredUsersCount: 6 },
    { title: "Joash's Antique Items Auction", registeredUsersCount: 3 },
    { title: "New Sandagiri Auctions", registeredUsersCount: 2 },
    { title: "Art Auction by BidMaster", registeredUsersCount: 5 },
    
  ];
  // Fetch the most registered auctions on mount
 
  // Prepare data for Bar chart
  const barChartData = {
    labels: mostRegisteredAuctions.map((auction) => auction.title), // Auction titles
    datasets: [
      {
        label: 'Registered Users Count',
        data: mostRegisteredAuctions.map((auction) => auction.registeredUsersCount), // Counts
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };
  

  const [mostExpensiveCategories, setMostExpensiveCategories] = useState([]);
  // Fetch most expensive categories on mount
useEffect(() => {
  axios
      .get("http://localhost:8070/item/analytics/most-expensive-categories")
      .then((response) => {
          setMostExpensiveCategories(response.data); // Store the category data for the table
      })
      .catch((error) => {
          console.error("Error fetching most expensive categories", error);
      });
}, []);
  
  

  
  const [categoryData, setCategoryData] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8070/item/analytics/categories")
      .then((response) => {
        setCategoryData(response.data); // Store the category data for the pie chart
      })
      .catch((error) => {
        console.error("Error fetching category data", error);
      });
  }, []);

  const chartData = {
    labels: categoryData.map((cat) => cat._id), // Category names
    datasets: [
      {
        data: categoryData.map((cat) => cat.count), // Counts
        backgroundColor: [
          "rgba(255, 99, 132, 0.6)",
          "rgba(54, 162, 235, 0.6)",
          "rgba(255, 206, 86, 0.6)",
          "rgba(75, 192, 192, 0.6)",
          // Add more colors if needed
        ],
      },
    ],
  };

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    console.log("token is : ",token)
    if (token) {
      axios
        .get("http://localhost:8070/seller/me", {
          headers: { authToken: token },
        })
        .then((response) => {
          if (response.data) {
            setSellerData(response.data);
            setFormData(response.data);
            fetchRegisteredAuctions(response.data._id); // Fetch auctions for this seller
          }
        })
        .catch((error) => {
          console.error("There was an error fetching the seller data!", error);
        });
    } else {
      console.error("No token found");
    }
  }, []);

  const fetchRegisteredAuctions = (userId) => {
    const token = localStorage.getItem("authToken");
    axios
      .post(
        "http://localhost:8070/auction/registered-auctions",
        { userId },
        {
          headers: { authToken: token },
        }
      )
      .then((response) => {
        setRegisteredAuctions(response.data); // Set registered auctions
      })
      .catch((error) => {
        console.error("Error fetching registered auctions", error);
      });
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const token = localStorage.getItem("authToken");
    if (token) {
      axios
        .put("http://localhost:8070/seller/me", formData, {
          headers: { authToken: token },
        })
        .then((response) => {
          setSellerData(response.data);
        })
        .catch((error) => {
          console.error("There was an error updating the seller data!", error);
        });
    }
  };

  const handleLogout = () => {
    const confirmLogout = window.confirm("Do you want to logout?");
    if (confirmLogout) {
      localStorage.removeItem("authToken"); // Remove the token from local storage
      navigate("/ItemListView"); // Navigate to the ItemListView page
    }
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    
    // Add company logo
    const logo = '/Assests/bid-master-logo-zip-file/png/logo-black.png'; // Replace with your Base64 image string
    doc.addImage(logo, 'PNG', 10, -10, 60, 60); // Adjust x, y, width, height as needed


     // Adding header information
     doc.setFontSize(12);
     doc.text("Bid Master", 100, 20); // Company Name
     doc.text("Arcade Independence Square, Colombo 07, Sri Lanka", 100, 25); // Company Address
     doc.text("Telephone: 070 5790678", 100, 30); // Telephone Number
     doc.text("Email: bidmaster@gmail.com", 100, 35); // Telephone Number
     doc.text(`Date: ${new Date().toLocaleDateString()}`, 100, 40); // Current Date
 


     // Adding section divider line
    doc.setLineWidth(0.5); // Set line width
    doc.line(10, 48, 200, 48); // Line from (x1, y1) to (x2, y2)
    // Adding title
    doc.setFontSize(18);
    doc.text("Analytics Report", 14, 45); // Adjust y position to avoid overlap with logo



    // Adding Most Available Item Categories
    doc.setFontSize(14);
    doc.text("Most Available Item Categories", 14, 55); // Adjust y position accordingly

    // Create table from categoryData
    const tableColumn = ["Category", "Count"];
    const tableRows = categoryData.map(cat => [cat._id, cat.count]);
    doc.autoTable(tableColumn, tableRows, { startY: 60 }); // Adjust startY as necessary


    //most expensive categories
    doc.text("Most expensive Item Categories", 14, 105); // Adjust y position accordingly
    const tableColumn1 = ["Category", "max Price($)"];
    const tableRows1 = mostExpensiveCategories.map(cat => [cat._id, cat.maxPrice]);
    doc.autoTable(tableColumn1, tableRows1, { startY: 110 }); // Adjust startY as necessary

    // Most registered auctions
doc.text("Most registered Item Categories", 14, 160); // Adjust y position accordingly

const tableColumn2 = ["Title", "Count"];

// Create the rows based on your auction data
const tableRows2 = mostRegisteredAuctions.map(auction => [auction.title, auction.registeredUsersCount]);

// Generate the table in the PDF
doc.autoTable(tableColumn2, tableRows2, { startY: 165 }); // Adjust


    
    // Save the PDF
    doc.save("analytics_report.pdf");
};


const generateQr = async () => {
  const doc = new jsPDF();

  // Generate QR code
  const qrCodeData = "Your QR Code Data Here"; // Replace with the data you want to encode
  const qrCodeImage = await QRCode.toDataURL(qrCodeData, { errorCorrectionLevel: 'H' });

  // Add QR code to PDF
  doc.addImage(qrCodeImage, 'PNG', 70, 10, 60, 60); // Adjust x, y, width, height as needed

  // Adding title
  doc.setFontSize(18);
  doc.text("QR Code Report", 14, 80); // Adjust y position as needed

  // Save the PDF
  doc.save("qr_code_report.pdf");
};


  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Nav
            variant="tabs"
            activeKey={activeTab}
            onSelect={(selectedKey) => setActiveTab(selectedKey)}
          >
            <Nav.Item>
              <Nav.Link eventKey="personal-details">Personal details</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="registered-auction">
                Registered auction
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="analytics">Analytics</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="edit-profile">Edit profile</Nav.Link>
            </Nav.Item>
          </Nav>
          <div className="card mt-4 p-4" style={{ marginBottom: 90 }}>
            {activeTab === "personal-details" && sellerData && (
              <>
                <div className="text-center">
                  <img
                    src="/Assests/defaultprofile.jpg"
                    alt="Profile"
                    className="rounded-circle mb-4"
                    style={{
                      width: "150px",
                      height: "150px",
                      backgroundColor: "#f0f0f0",
                    }}
                  />
                </div>

                <Form>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Email :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={sellerData.email}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Name :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={`${sellerData.firstName} ${sellerData.lastName}`}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Address :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={sellerData.address}
                      />
                    </Col>
                  </Form.Group>
                  
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Company :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={sellerData.companyName || "N/A"}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Birth Day :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={new Date(
                          sellerData.birthday
                        ).toLocaleDateString()}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Phone Number :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        plaintext
                        readOnly
                        defaultValue={sellerData.contactInfo}
                      />
                    </Col>
                  </Form.Group>
                  {/* Logout Button */}
                  <div className="text-center mt-4">
                    <Button variant="danger" onClick={handleLogout}>
                      Logout
                    </Button>
                  </div>
                </Form>
                <div className="text-center mt-4">
                  <Button variant="primary">
                    <a
                      href="/readproduct"
                      style={{
                        color: "white",
                        textDecoration: "none",
                      }}
                    >
                      my orders
                    </a>
                  </Button>
                  
                </div>
                <a href="/Admin">Admin?</a>
              </>
            )}

            {activeTab === "registered-auction" &&
              registeredAuctions.length > 0 && (
                <div>
                  <h5>Registered Auctions</h5>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th>Starting Date & Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {registeredAuctions.map((auction) => {
                        const formattedDate = new Date(
                          auction.startingDateTime
                        ).toLocaleString(); // Format the date and time
                        return (
                          <tr key={auction._id}>
                            <td>{auction.title}</td>
                            <td>{formattedDate}</td>
                            <td>
                              <button>
                                <Link to={`/auction/${auction._id}`}
                                style={{
                                  textDecoration:"none",
                                  color:"black"
                                }}
                                >Visit</Link>
                              </button>
                            </td>
                            <td>
                              <button onClick={generateQr} >
                                
                              <i class="fas fa-download"></i>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            {activeTab === "analytics" && categoryData.length > 0 && (
              <div>
                <div style={{ width: "300px", height: "300px" }}>
                  <h5
                  >Most Available Item Categories</h5>
                  <Pie
                    data={chartData}
                    width={20} // Set the width as needed
                    height={20} // Set the height as needed/
                  ></Pie>
                </div>
                <br></br>
                <br></br>
                <br></br>
                

                <div>

                <h4>Most Expensive Item Categories</h4>
                            <table className="table table-bordered mt-3">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Max Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mostExpensiveCategories.map((cat, index) => (
                                        <tr key={index}>
                                            <td>{cat._id}</td>
                                            <td>{cat.maxPrice} $</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            <h4>Most Registered Auctions</h4>
                <div style={{ width: "600px", height: "400px" }}>
                  <Bar
                    data={barChartData}
                    options={{
                      responsive: true,
                      scales: {
                        y: {
                          beginAtZero: true,
                        },
                      },
                    }}
                  />
                </div>
    
  </div>
                <Button variant="primary" onClick={generatePDF} className="mt-4">
                  Download Report
                </Button>
              </div>
            )}

            {activeTab === "edit-profile" && sellerData && (
              <>
                <Form onSubmit={handleSubmit}>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Email :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="email"
                        name="email"
                        value={formData.email || ""}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Name :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="firstName"
                        value={formData.firstName || ""}
                        onChange={handleEditChange}
                      />
                      <Form.Control
                        type="text"
                        name="lastName"
                        value={formData.lastName || ""}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Address :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="address"
                        value={formData.address || ""}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-3">
                    <Form.Label column sm="3">
                      <strong>Phone Number :</strong>
                    </Form.Label>
                    <Col sm="9">
                      <Form.Control
                        type="text"
                        name="contactInfo"
                        value={formData.contactInfo || ""}
                        onChange={handleEditChange}
                      />
                    </Col>
                  </Form.Group>
                  <Button type="submit" variant="primary">
                    Save Changes
                  </Button>
                </Form>
              </>
            )}
          </div>
        </Col>
      </Row>
    </Container>
  );
}
