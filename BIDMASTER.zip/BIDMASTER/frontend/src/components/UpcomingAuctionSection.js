import React, { useEffect, useState } from "react";
import axios from "axios";
import "../UpcomingAuctionSection.css";

const URL = "http://localhost:8070/ads";

export default function UpcomingAuctionSection() {
  const [advertisementDetails, setAdvertisementDetails] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [isFading, setIsFading] = useState(false);

  const fetchAdvertisementDetails = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get(URL);
      setAdvertisementDetails(response.data.ads);
      setError(null);
    } catch (error) {
      console.error("Error fetching advertisement details:", error);
      setError("There was an error fetching the advertisements.");
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return dateString.split("T")[0];
  };

  useEffect(() => {
    fetchAdvertisementDetails();
  }, []);

  useEffect(() => {
    const intervalId = setInterval(() => {
      triggerNextAd();
    }, 10000); // Change ad every 10 seconds

    return () => clearInterval(intervalId);
  }, [advertisementDetails.length]);

  const triggerNextAd = () => {
    setIsFading(true);
    setTimeout(() => {
      setCurrentAdIndex(
        (prevIndex) => (prevIndex + 1) % advertisementDetails.length
      );
      setIsFading(false);
    }, 500);
  };

  const handleNext = () => {
    triggerNextAd();
  };

  const handlePrevious = () => {
    setIsFading(true);
    setTimeout(() => {
      setCurrentAdIndex(
        (prevIndex) =>
          (prevIndex - 1 + advertisementDetails.length) %
          advertisementDetails.length
      );
      setIsFading(false);
    }, 500);
  };

  const fadeStyle = {
    transition: "opacity 0.5s ease-in-out",
    opacity: isFading ? 0 : 1,
  };

  return (
    <div className="containerxv">
      {isLoading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="banner" style={{ position: "relative" }}>
          {advertisementDetails.length > 0 ? (
            <div className="ad-item" style={fadeStyle}>
              <div className="image-container">
                {advertisementDetails[currentAdIndex].image && (
                  <img
                    src={advertisementDetails[currentAdIndex].image}
                    alt={advertisementDetails[currentAdIndex].title}
                    className="ad-image"
                    style={{
                      width: "120%",
                      height: "auto",
                      borderRadius: "8px",
                      maxHeight: "500px",
                      objectFit: "cover",
                    }}
                  />
                )}
              </div>
              <div
                className="ad-details"
                style={{ padding: "50px", textAlign: "center" }}
              >
                <h4 className="ad-title">
                  {advertisementDetails[currentAdIndex].title}
                </h4>
                <p className="ad-description">
                  {advertisementDetails[currentAdIndex].description}
                </p>
                <p className="ad-date">
                  {formatDate(advertisementDetails[currentAdIndex].date)}
                </p>
              </div>
            </div>
          ) : (
            <p>No Advertisements</p>
          )}
          <div
            className="navigation-arrows"
            style={{
              position: "absolute",
              top: "93%",
              left: "0",
              right: "0",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              transform: "translateY(-50%)",
            }}
          >
            <span
              onClick={handlePrevious}
              className="arrow left-arrow"
              style={{
                cursor: "pointer",
                fontSize: "40px",
                marginLeft: "20px",
                userSelect: "none",
              }}
            >
              &#10094;
            </span>
            <span
              onClick={handleNext}
              className="arrow right-arrow"
              style={{
                cursor: "pointer",
                fontSize: "40px",
                marginRight: "20px",
                userSelect: "none",
              }}
            >
              &#10095;
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
