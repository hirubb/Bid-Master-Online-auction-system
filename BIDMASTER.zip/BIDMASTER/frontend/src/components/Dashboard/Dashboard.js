import React, { useEffect, useState, useRef } from "react";
import Nav from "../Nav2/Nav2";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  LineChart,
  Line,
} from "recharts";
import axios from "axios";

const URL = "http://localhost:8070/ads";

function Dashboard() {
  const [adsCatData, setAdsCatData] = useState([]);
  const [adProgressData, setAdProgressData] = useState([]);
  const [submissionTrendData, setSubmissionTrendData] = useState([]);
  const [animationKey, setAnimationKey] = useState(0);

  // Create refs for each chart
  const pieChartRef = useRef(null);
  const barChartRef = useRef(null);
  const lineChartRef = useRef(null);

  useEffect(() => {
    const fetchAdsData = async () => {
      try {
        const response = await axios.get(URL);
        const advertisements = response.data.ads;
        const titleCounts = {};

        advertisements.forEach((ad) => {
          // Normalize the title to lowercase and trim whitespace
          const title = ad.title.trim().toLowerCase();
          titleCounts[title] = (titleCounts[title] || 0) + 1;
        });

        // Convert to the required format for the pie chart
        const formattedData = Object.entries(titleCounts)
          .map(([name, value]) => ({
            name: name.charAt(0).toUpperCase() + name.slice(1),
            value,
          })) // Capitalize first letter of title
          .filter((entry) => entry.name !== ""); // Remove empty titles if needed

        setAdsCatData(formattedData);
        setAnimationKey((prevKey) => prevKey + 1);

        updateAdProgress(advertisements);
        updateSubmissionTrend(advertisements);
      } catch (error) {
        console.error("Error fetching advertisement data:", error);
      }
    };

    fetchAdsData();
  }, []);

  const updateAdProgress = (advertisements) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const ongoingCount = advertisements.filter((ad) => {
      const adDate = new Date(ad.date);
      adDate.setHours(0, 0, 0, 0);
      return adDate.getTime() === today.getTime();
    }).length;

    const upcomingCount = advertisements.filter(
      (ad) => new Date(ad.date) > today
    ).length;
    const successfulCount = advertisements.filter(
      (ad) => new Date(ad.date) < today
    ).length;

    setAdProgressData([
      { name: "Ongoing", value: ongoingCount },
      { name: "Upcoming", value: upcomingCount },
      { name: "Successful", value: successfulCount },
    ]);
  };

  const updateSubmissionTrend = (advertisements) => {
    const trendData = [
      { date: "2024-09-25", submissions: 5 },
      { date: "2024-09-26", submissions: 10 },
      { date: "2024-09-27", submissions: 15 },
      { date: "2024-09-28", submissions: 20 },
      { date: "2024-09-29", submissions: 12 },
      { date: "2024-09-30", submissions: 18 },
    ];
    setSubmissionTrendData(trendData);
  };

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        margin: 0,
        padding: 0,
        width: "100vw", // Ensure full width
      }}
    >
      <Nav />
      <div
        style={{
          flex: 1,
          padding: "20px",
          backgroundColor: "#f9f9f9",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "100%", // Ensure full width
        }}
      >
        <section style={{ width: "100%", maxWidth: "1200px" }}>
          <h2>Your Advertisement Progress</h2>
          <div style={{ marginBottom: "20px" }} />
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "20px",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {/* Advertisement Categories - Pie Chart */}
            <div ref={pieChartRef} style={chartContainerStyle}>
              <h3>Advertisement Categories</h3>
              <PieChart width={200} height={200} key={animationKey}>
                <Pie
                  data={adsCatData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  animationDuration={800}
                  animationEasing="ease-out"
                >
                  {adsCatData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
              <div style={{ marginTop: "10px" }}>
                {adsCatData.map((entry, index) => (
                  <div
                    key={index}
                    style={{ color: COLORS[index % COLORS.length] }}
                  >
                    {entry.name}: {entry.value}
                  </div>
                ))}
              </div>
            </div>

            {/* Advertisement Progress - Horizontal Bar Chart */}
            <div ref={barChartRef} style={chartContainerStyle}>
              <h3>Advertisement Progress</h3>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <BarChart
                  width={300}
                  height={200}
                  data={adProgressData}
                  layout="vertical"
                  margin={{ top: 20, right: 20, left: 20, bottom: 20 }}
                  key={animationKey}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis type="category" dataKey="name" />
                  <Tooltip />
                  <Bar
                    dataKey="value"
                    fill="#8884d8"
                    animationDuration={1000}
                    animationEasing="ease-in-out"
                  />
                </BarChart>
              </div>
              <div style={{ marginTop: "10px" }}>
                {adProgressData.map((entry, index) => (
                  <div
                    key={index}
                    style={{ color: COLORS[index % COLORS.length] }}
                  >
                    {entry.name}: {entry.value}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Advertisement Submission Trend - Line Chart */}
          <div
            ref={lineChartRef}
            style={{
              textAlign: "center",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              border: "1px solid #ddd",
              borderRadius: "5px",
              padding: "10px",
              marginTop: "20px",
              width: "100%",
              maxWidth: "600px",
              marginLeft: "auto",
              marginRight: "auto",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
            }}
          >
            <h3>Advertisement Submission Trend</h3>
            <div style={{ display: "flex", justifyContent: "center" }}>
              <LineChart
                width={600}
                height={200}
                data={submissionTrendData}
                margin={{ top: 20, right: 20, left: 20, bottom: 20 }}
                key={animationKey}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="submissions"
                  stroke="#82ca9d"
                  fill="#82ca9d"
                  animationDuration={1000}
                  animationEasing="ease-in-out"
                />
              </LineChart>
            </div>
            <div style={{ marginTop: "10px" }}>
              {submissionTrendData.map((entry, index) => (
                <div key={index} style={{ color: "#82ca9d" }}>
                  {entry.date}: {entry.submissions} submissions
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

// Style for chart container
const chartContainerStyle = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  textAlign: "center",
  backgroundColor: "rgba(255, 255, 255, 0.8)",
  border: "1px solid #ddd",
  borderRadius: "5px",
  padding: "10px",
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
  minWidth: "200px", // Ensures minimum width for charts
};

export default Dashboard;
