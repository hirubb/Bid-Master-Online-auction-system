import React, { useEffect, useState } from "react";
import Nav from "../Nav2/Nav2";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import "jspdf-autotable";

const URL = "http://localhost:8070/ads";

const fetchHandler = async () => {
  return await axios.get(URL).then((res) => res.data);
};

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toISOString().split("T")[0];
};

const formatCurrentDateTime = () => {
  const now = new Date();
  const options = {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  };
  return now.toLocaleString("en-US", options).replace(",", ""); // Remove comma between date and time
};

function AdvertismentDetails() {
  const [advertisementDetails, setAdvertisementDetails] = useState([]);
  const [searchInput, setSearchInput] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAndDeleteExpiredAds = async () => {
      const data = await fetchHandler();
      const currentAds = data.ads;
      const today = new Date().toISOString().split("T")[0];

      const validAds = [];
      for (const ad of currentAds) {
        const adDate = formatDate(ad.date);
        if (adDate < today) {
          await handleDelete(ad._id);
        } else {
          validAds.push(ad);
        }
      }

      setAdvertisementDetails(validAds);
    };

    fetchAndDeleteExpiredAds();
  }, []);

  const handleEdit = (id) => {
    const confirmEdit = window.confirm(
      "Are you sure you want to update this advertisement?"
    );
    if (!confirmEdit) return;

    navigate(`/update-advertisement/${id}`);
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this advertisement?"
    );
    if (!confirmDelete) return;

    try {
      await axios.delete(`${URL}/${id}`);
      setAdvertisementDetails((prevAds) =>
        prevAds.filter((ad) => ad._id !== id)
      );
    } catch (error) {
      console.error("Error deleting advertisement:", error);
    }
  };

  const filteredAdvertisements = advertisementDetails.filter((ad) => {
    const normalizedInput = searchInput.toLowerCase();
    const matchesTitle = ad.title.toLowerCase().includes(normalizedInput);
    const matchesDate = formatDate(ad.date) === normalizedInput;
    return matchesTitle || matchesDate;
  });

  const getImageData = async (url) => {
    try {
      const response = await fetch(url, { mode: "cors" });
      if (!response.ok) throw new Error("Network response was not ok.");
      const blob = await response.blob();
      const reader = new FileReader();
      return new Promise((resolve, reject) => {
        reader.onloadend = () => {
          resolve(reader.result); // This is the Data URL
        };
        reader.onerror = (error) => {
          console.error("Error reading blob as Data URL:", error);
          reject(error);
        };
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error("Error fetching image:", error);
      return ""; // Return an empty string if there's an error
    }
  };

  const generatePDF = async () => {
    const doc = new jsPDF();
    const logoUrl =
      "http://localhost:3000/Assests/bid-master-logo-zip-file/png/logo-black.png"; // Replace with your logo URL
    const logoImage = await getImageData(logoUrl); // Fetch the logo as a Data URL

    if (logoImage) {
      const imgWidth = 70; // Set the desired width in mm
      const imgHeight = 70; // Set the desired height in mm
      const xPosition = (doc.internal.pageSize.getWidth() - imgWidth) / 2; // Center the logo horizontally
      doc.addImage(logoImage, "PNG", xPosition, 10, imgWidth, imgHeight); // Add logo at fixed position
    }

    // Add contact information below the logo
    doc.setFontSize(12);
    doc.text("Mail us: bidmaster@gmail.com", 14, 85); // Adjust Y position for contact info
    doc.text(
      "Find us: Arcade Independence Square, Colombo 07, Sri Lanka",
      14,
      90
    );
    doc.text("Call us: +94 xxxxxxxxx", 14, 95);

    // Draw a horizontal line after the contact information
    const pageWidth = doc.internal.pageSize.getWidth();
    doc.setLineWidth(0.5);
    doc.line(14, 100, pageWidth - 14, 100); // Line from left to right margin

    // Add date and time at the top right corner
    const currentDateTime = formatCurrentDateTime();
    doc.setFontSize(10);
    doc.text(currentDateTime, doc.internal.pageSize.getWidth() - 14, 15, {
      align: "right",
    }); // Align to the right corner

    // Add title below the line
    doc.setFontSize(16);
    doc.text("Advertisement Details", 14, 110); // Adjust Y position for title

    const columns = ["Image", "Title", "Date", "Description"];
    const rows = [];

    for (const ad of filteredAdvertisements) {
      const imageData = await getImageData(ad.image);
      if (imageData) {
        rows.push([imageData, ad.title, formatDate(ad.date), ad.description]);
      } else {
        rows.push(["No Image", ad.title, formatDate(ad.date), ad.description]);
      }
    }

    // Generate the table with black and white colors
    doc.autoTable({
      head: [columns],
      body: rows,
      startY: 115, // Adjust this to position the table below the title
      styles: {
        fontSize: 10, // Set font size for table
        textColor: [0, 0, 0], // Black text color
        lineColor: [0, 0, 0], // Black border color
        fillColor: [255, 255, 255], // White background color
      },
      headStyles: {
        fillColor: [255, 255, 255], // White background for headers
        textColor: [0, 0, 0], // Black text color for headers
        lineWidth: 0.1, // Set a thin border
      },
      bodyStyles: {
        fillColor: [255, 255, 255], // White background for rows
        textColor: [0, 0, 0], // Black text color for rows
        lineWidth: 0.1, // Set a thin border
      },
      columnStyles: {
        0: { cellWidth: 30, halign: "center" }, // Set the width of the Image column
      },
      didDrawCell: (data) => {
        if (
          data.column.index === 0 &&
          data.cell.raw &&
          data.cell.raw.startsWith("data:image/")
        ) {
          const { x, y, width, height } = data.cell;
          const image = data.cell.raw;
          const imgWidth = 30; // Width in mm
          const imgHeight = (imgWidth * height) / width; // Maintain aspect ratio
          doc.addImage(image, "PNG", x + 2, y + 2, imgWidth, imgHeight);
        }
      },
    });

    // Add page numbering at the bottom-right corner
    // Add page numbering at the bottom center of each page with a smaller font size
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);

      // Set a smaller font size for the page count
      doc.setFontSize(8); // Adjust the font size to a smaller value (e.g., 8)

      // Get the current page width and calculate the x position for center alignment
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageNumberText = `Page ${i} of ${pageCount}`;
      const textWidth = doc.getTextWidth(pageNumberText); // Get the width of the text
      const xPosition = (pageWidth - textWidth) / 2; // Center the text

      // Add the page number at the bottom of the page
      doc.text(
        pageNumberText,
        xPosition,
        doc.internal.pageSize.getHeight() - 10
      );
    }

    doc.save("advertisement_details.pdf");
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        backgroundColor: "#f9f9f9",
      }}
    >
      <Nav />
      <div
        style={{
          flex: 1,
          padding: "20px",
          marginLeft: "50px", // Adjusted margin left for better alignment
          boxSizing: "border-box",
        }}
      >
        <h1>Advertisement Details</h1>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "20px",
          }}
        >
          <input
            type="text"
            placeholder="Search by title or date (YYYY-MM-DD)"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            style={{
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "4px",
              fontSize: "16px",
              width: "300px",
              transition: "border-color 0.3s",
            }}
          />
          <button
            onClick={generatePDF}
            style={{
              padding: "10px 20px",
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
              transition: "background-color 0.3s, transform 0.3s", // Smooth transition for background color and scale
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = "#0056b3"; // Darker shade on hover
              e.currentTarget.style.transform = "scale(1.05)"; // Scale up the button slightly
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = "#007bff"; // Reset background color
              e.currentTarget.style.transform = "scale(1)"; // Reset scale
            }}
          >
            Generate PDF
          </button>
        </div>

        <div style={{ overflowX: "auto" }}>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              marginTop: "20px",
              marginLeft: "0", // Reset left margin to align with the container
            }}
          >
            <thead>
              <tr>
                <th
                  style={{
                    padding: "10px",
                    border: "1px solid #dad2d2",
                    backgroundColor: "#f4f4f4",
                    fontWeight: "bold",
                  }}
                >
                  Image
                </th>
                <th style={{ padding: "10px", border: "1px solid #dad2d2" }}>
                  Title
                </th>
                <th style={{ padding: "10px", border: "1px solid #dad2d2" }}>
                  Description
                </th>
                <th style={{ padding: "10px", border: "1px solid #dad2d2" }}>
                  Date
                </th>
                <th style={{ padding: "10px", border: "1px solid #dad2d2" }}>
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredAdvertisements.length > 0 ? (
                filteredAdvertisements.map((advertisement) => (
                  <tr
                    key={advertisement._id}
                    style={{ transition: "background-color 0.3s" }}
                  >
                    <td
                      style={{ padding: "10px", border: "1px solid #dad2d2" }}
                    >
                      <img
                        src={advertisement.image}
                        alt={advertisement.title}
                        style={{ width: "100px", height: "auto" }}
                      />
                    </td>
                    <td
                      style={{ padding: "10px", border: "1px solid #dad2d2" }}
                    >
                      {advertisement.title}
                    </td>
                    <td
                      style={{ padding: "10px", border: "1px solid #dad2d2" }}
                    >
                      {advertisement.description}
                    </td>
                    <td
                      style={{ padding: "10px", border: "1px solid #dad2d2" }}
                    >
                      {formatDate(advertisement.date)}
                    </td>
                    <td
                      style={{ padding: "10px", border: "1px solid #dad2d2" }}
                    >
                      <button
                        onClick={() => handleEdit(advertisement._id)}
                        style={{
                          marginRight: "10px",
                          backgroundColor: "#28a745", // Green color
                          border: "none",
                          padding: "5px 10px",
                          borderRadius: "4px",
                          cursor: "pointer",
                          color: "white",
                          transition: "background-color 0.3s, transform 0.3s", // Transition for background color and scale
                        }}
                        onMouseOver={(e) => {
                          e.currentTarget.style.backgroundColor = "#218838"; // Darker green on hover
                          e.currentTarget.style.transform = "scale(1.05)"; // Scale up the button slightly
                        }}
                        onMouseOut={(e) => {
                          e.currentTarget.style.backgroundColor = "#28a745"; // Reset background color
                          e.currentTarget.style.transform = "scale(1)"; // Reset scale
                        }}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(advertisement._id)}
                        style={{
                          backgroundColor: "#dc3545",
                          border: "none",
                          padding: "5px 10px",
                          borderRadius: "4px",
                          color: "white",
                          cursor: "pointer",
                          transition: "background-color 0.3s, transform 0.3s", // Transition for background color and scale
                        }}
                        onMouseOver={(e) => {
                          e.currentTarget.style.backgroundColor = "#c82333"; // Darker red on hover
                          e.currentTarget.style.transform = "scale(1.05)"; // Scale up the button slightly
                        }}
                        onMouseOut={(e) => {
                          e.currentTarget.style.backgroundColor = "#dc3545"; // Reset background color
                          e.currentTarget.style.transform = "scale(1)"; // Reset scale
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="5"
                    style={{ padding: "10px", textAlign: "center" }}
                  >
                    No advertisements found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default AdvertismentDetails;
