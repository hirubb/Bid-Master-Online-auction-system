import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ManageItems() {
    const [items, setItems] = useState([]);
    const [searchQuery, setSearchQuery] = useState(""); // State for search query

    useEffect(() => {
        const fetchItems = async () => {
            try {
                const response = await axios.get("http://localhost:8070/item"); // Update with your endpoint
                setItems(response.data);
            } catch (error) {
                console.error("Error fetching items:", error);
            }
        };
        fetchItems();
    }, []);

    const deleteItem = async (name) => {
        try {
            const response = await axios.delete(`http://localhost:8070/item/delete/${name}`);
            alert(response.data.message);
            setItems(items.filter(item => item.name !== name)); // Remove the deleted item from state
        } catch (error) {
            console.error("Error deleting item:", error);
        }
    };

    // Filter items based on the search query
    const filteredItems = items.filter((item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div>
            <h1>Manage Items</h1>

            {/* Search bar */}
            <input
                type="text"
                className="form-control mb-3"
                placeholder="Search by item name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)} // Update search query
            />

            <table className="table">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Starting Price</th>
                        <th>Seller Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredItems.map(item => (
                        <tr key={item._id}>
                            <td>{item.name}</td>
                            <td>{item.startingPrice}</td>
                            <td>{item.registeredSeller ? item.registeredSeller._id : "N/A"}</td>
                            <td>{item.description}</td>
                            <td>
                                <button onClick={() => deleteItem(item.name)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
